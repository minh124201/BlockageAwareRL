"""Regression tests for the reference simulator."""
