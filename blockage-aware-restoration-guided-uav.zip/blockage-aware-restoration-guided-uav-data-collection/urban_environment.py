"""Single-UAV interface to the original uav_data_harvesting environment.

Uses the original Grid, Physics, Rewards, State and Channel modules.
No alternative simulation, no TensorFlow and no code embedded in notebooks.
"""
import json
from pathlib import Path
import numpy as np
from src.Grid import Grid, GridParams
from src.Physics import Physics, PhysicsParams
from src.Rewards import Rewards, RewardParams
from src.base.GridActions import GridActions

PROJECT_ROOT = Path(__file__).resolve().parent


class CallbackStats:
    """Small callback sink: original Grid/Physics/Rewards use stats only for logs."""
    def set_env_map_callback(self, callback):
        pass

    def set_evaluation_value_callback(self, callback):
        pass

    def add_log_data_callback(self, name, callback):
        pass


def load_config(map_name="manhattan32"):
    if map_name not in ("manhattan32", "urban50", "manhattan32_blockage", "urban50_blockage", "manhattan32_baer3d"):
        raise ValueError("map_name must be 'manhattan32' or 'urban50'")
    with (PROJECT_ROOT / 'config' / (map_name + '.json')).open(encoding='utf8') as f:
        return json.load(f)


class BeforeStep:
    """Snapshot only the pre-action fields required by original Rewards."""
    def __init__(self, state):
        # Preserve list type: original next_state.position is a list after a step.
        # Converting to tuple would make every position comparison incorrectly unequal.
        self.position = list(state.position)
        self.remaining_data = float(state.get_remaining_data())

    def get_remaining_data(self):
        return self.remaining_data


class UAVHarvesting1UAV:
    def __init__(self, config):
        stats = CallbackStats()
        source = config['grid_params']
        g = GridParams()
        g.map_path = str(PROJECT_ROOT / source['map_path'])
        g.movement_range = source['movement_range']
        g.multi_agent = False
        g.num_agents_range = [1, 1]
        g.fixed_starting_idcs = source.get('fixed_starting_idcs', False)
        if g.fixed_starting_idcs:
            g.starting_idcs = source['starting_idcs']
        dev = source['device_manager']
        g.device_manager.device_count_range = dev['device_count_range']
        g.device_manager.data_range = dev['data_range']
        g.device_manager.fixed_devices = dev.get('fixed_devices', False)
        self.grid = Grid(g, stats)

        p = PhysicsParams()
        p.comm_steps = config['physics_params']['comm_steps']
        p.flight_params = config['physics_params'].get('flight3d')
        for key, value in config['physics_params']['channel_params'].items():
            setattr(p.channel_params, key,
                    str(PROJECT_ROOT / value) if key in ('map_path', 'building_height_map') and value else value)
        self.physics = Physics(p, stats)

        r = RewardParams()
        for key, value in config['reward_params'].items():
            setattr(r, key, value)
        self.rewards = Rewards(r, stats)

        self.state = None
        self.steps = 0
        self.actions = list(GridActions)
        self.max_budget = int(g.movement_range[1])
        self.max_device_data = float(g.device_manager.data_range[1])
        self.global_pool = int(config['agent_params']['global_map_scaling'])
        self.local_width = int(config['agent_params']['local_map_size'])

    def reset(self, seed=None):
        if seed is not None:
            np.random.seed(int(seed))
        self.state = self.grid.init_episode()
        self.physics.reset(self.state, channel_seed=seed)
        self.rewards.reset()
        self.steps = 0
        assert self.state.num_agents == 1 and self.state.multi_agent is False
        return self.state

    def step(self, action_idx):
        assert self.state is not None and not self.state.all_terminal
        before = BeforeStep(self.state)
        action = GridActions(int(action_idx))
        self.state = self.physics.step(action)
        reward = float(self.rewards.calculate_reward(before, action, self.state))
        self.steps += 1
        return self.state, reward, bool(self.state.all_terminal)

    def metrics(self):
        s = self.state
        result = {
            'reward': float(self.rewards.cumulative_reward),
            'collection_ratio': float(s.get_collection_ratio()),
            'cral': float(s.get_collection_ratio() * s.all_landed),
            'landed': int(s.all_landed),
            'steps_used': int(self.steps),
            'boundary_counter': int(self.physics.boundary_counter),
            'landing_attempts': int(self.physics.landing_attempts),
            'collected_data': float(s.get_collected_data()),
            'total_data': float(s.get_total_data()),
        }
        if hasattr(s, 'initial_energy_j'):
            result.update(energy_used_j=float(self.physics.episode_energy_j),
                          energy_initial_j=float(s.initial_energy_j),
                          energy_remaining_j=float(s.energy_j),
                          final_altitude_m=float(s.altitude_m))
        # Evaluation-only device completion metrics; do not affect physics/reward.
        devices = s.device_list.devices
        fully = sum(int(d.depleted) for d in devices)
        result.update(iot_total=int(len(devices)),
                      iot_fully_collected=int(fully),
                      iot_success_ratio=float(fully/max(1,len(devices))),
                      iot_partially_collected=int(sum(0.0 < d.collected_data < d.data - 1e-8 for d in devices)))
        result.update(self.physics.link_metrics)
        result.update(self.physics.channel.link_query_metrics)
        selected_links = result['los_tx'] + result['nlos_tx']
        result['selected_nlos_fraction'] = (result['nlos_tx'] / selected_links
                                             if selected_links else 0.0)
        result['los_mean_rate'] = (result['los_rate_sum'] / result['los_tx']
                                   if result['los_tx'] else 0.0)
        result['nlos_mean_rate'] = (result['nlos_rate_sum'] / result['nlos_tx']
                                    if result['nlos_tx'] else 0.0)
        return result

    def encode(self, state=None):
        """Original centered maps -> global/local CHW tensors + normalized budget.

        The global downsampling reproduces valid-window AvgPool2D used in the
        original CNN, while all maps still come from original State methods.
        """
        if state is None:
            state = self.state
        boolean_map = state.get_boolean_map().astype(np.float32)
        float_map = (state.get_float_map() / self.max_device_data).astype(np.float32)
        channels = np.concatenate((boolean_map, float_map), axis=-1)
        h, w, c = channels.shape
        k = self.global_pool
        gh, gw = h // k, w // k
        global_map = channels[:gh*k, :gw*k, :].reshape(gh,k,gw,k,c).mean(axis=(1,3))
        L = self.local_width
        sy, sx = (h-L)//2, (w-L)//2
        local_map = channels[sy:sy+L, sx:sx+L, :]
        if hasattr(state,'initial_energy_j'):
            b_max = self.max_budget
            budget = np.asarray([state.movement_budget/b_max,
                 state.energy_j/max(state.initial_energy_j,1e-9),
                 (state.altitude_m-self.physics.flight_graph.min_height)/(
                    self.physics.flight_graph.height_levels[-1]-self.physics.flight_graph.min_height),
                 state.last_no_service_fraction, state.last_collection_fraction],dtype=np.float32)
        else:
            budget = np.asarray([state.movement_budget / self.max_budget], dtype=np.float32)
        return (global_map.transpose(2,0,1).astype(np.float16),
                local_map.transpose(2,0,1).astype(np.float16), budget)
