from __future__ import annotations

import numpy as np

from src.Channel import ChannelParams, Channel
from src.State import State
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from src.ModelStats import ModelStats
from src.base.GridActions import GridActions
from src.base.GridPhysics import GridPhysics
from src.Flight3D import FlightGraph


class PhysicsParams:
    def __init__(self):
        self.channel_params = ChannelParams()
        self.comm_steps = 4
        self.flight_params = None


class Physics(GridPhysics):

    def __init__(self, params: PhysicsParams, stats: ModelStats):

        super().__init__()

        self.channel = Channel(params.channel_params)

        self.params = params

        self.register_functions(stats)
        self.link_metrics = {}
        self._reset_link_metrics()
        self.flight_graph = None
        self.recovery_steps = 0
        self.recovery_energy = 0.0

    def register_functions(self, stats: ModelStats):
        stats.set_evaluation_value_callback(self.get_cral)

        stats.add_log_data_callback('cral', self.get_cral)
        stats.add_log_data_callback('cr', self.get_collection_ratio)
        stats.add_log_data_callback('successful_landing', self.has_landed)
        stats.add_log_data_callback('boundary_counter', self.get_boundary_counter)
        stats.add_log_data_callback('landing_attempts', self.get_landing_attempts)
        stats.add_log_data_callback('movement_ratio', self.get_movement_ratio)

    def _reset_link_metrics(self):
        self.link_metrics = {
            'los_tx': 0, 'nlos_tx': 0, 'outage_tx': 0, 'no_service_slots': 0,
            'los_collected': 0.0, 'nlos_collected': 0.0,
            'los_rate_sum': 0.0, 'nlos_rate_sum': 0.0,
            'restored_events': 0, 'recovery_delay_sum': 0, 'recovery_energy_sum': 0.0,
            'blockage_no_service_steps':0, 'blockage_restored_events':0,
        }

    def reset(self, state: State, channel_seed=None):
        GridPhysics.reset(self, state)
        self.channel.reset(self.state.shape[0], scenario_seed=channel_seed)
        self._reset_link_metrics()
        self.recovery_steps = 0
        self.recovery_energy = 0.0
        self.recovery_blocked = False
        if self.params.flight_params is not None:
            if self.channel.mode != 'urban3d':
                raise ValueError('3D flight requires urban3d channel')
            if self.flight_graph is None:
                self.flight_graph = FlightGraph(state.no_fly_zone,
                    self.channel.building_heights, state.landing_zone, self.params.flight_params)
            self.state.altitude_index = 0
            self.state.altitude_m = self.flight_graph.min_height
            self.state.energy_reference_j = self.flight_graph.reference_cost
            self.state.initial_energy_j = float(state.initial_movement_budget)*self.flight_graph.reference_cost
            self.state.energy_j = self.state.initial_energy_j
            self.state.last_no_service_fraction = 0.0
            self.state.last_collection_fraction = 0.0
            self.state.last_action_energy_j = 0.0
            self.state.energy_exhausted = False
            self.state.last_invalid_action = False
            self.episode_energy_j = 0.0

    def movement_step(self, action: GridActions):
        if self.params.flight_params is None:
            return GridPhysics.movement_step(self, action)
        graph=self.flight_graph
        x,y=self.state.position
        old_node=(int(x),int(y),int(self.state.altitude_index))
        ai=int(action.value)
        candidate=graph.after(old_node,ai)
        valid=graph.action_valid(old_node,ai)
        self.state.last_invalid_action = not valid and ai != 5
        if ai==4:
            self.landing_attempts += 1
        elif not valid and ai!=5:
            self.boundary_counter += 1
        if valid and ai in (0,1,2,3,6,7):
            self.state.set_position([candidate[0],candidate[1]])
            self.state.altitude_index = candidate[2]
            self.state.altitude_m = graph.height_levels[candidate[2]]
        cost=float(graph.costs[ai])
        old_energy=float(self.state.energy_j)
        self.state.last_action_energy_j=cost
        self.state.energy_j=max(0.0,self.state.energy_j-cost)
        self.episode_energy_j+=cost
        if ai==4 and valid and cost<=old_energy+1.e-6:
            self.state.set_landed(True)
        self.state.decrement_movement_budget()
        depleted=(self.state.energy_j <= 1.e-6 or self.state.movement_budget<=0)
        self.state.energy_exhausted=bool(depleted and not self.state.landed)
        self.state.set_terminal(self.state.landed or depleted)
        return self.state.position

    def step(self, action: GridActions):
        old_position = list(self.state.position)
        old_alt = getattr(self.state,'altitude_m',None)
        old_data = float(self.state.get_collected_data())
        old_noservice=int(self.link_metrics['no_service_slots'])
        self.movement_step(action)
        if not self.state.terminal:
            self.comm_step(old_position,old_alt)
        if self.params.flight_params is not None:
            gained=float(self.state.get_collected_data())-old_data
            ns=int(self.link_metrics['no_service_slots'])-old_noservice
            self.state.last_no_service_fraction=float(ns)/self.params.comm_steps
            self.state.last_collection_fraction=gained/max(1e-9,float(self.state.initial_total_data))
            self.state.last_blockage_outage = self._geometric_blockage_outage()
            if ns==self.params.comm_steps and self.state.last_blockage_outage:
                self.link_metrics['blockage_no_service_steps']+=1
            if not self.state.terminal and gained<=1e-12 and self.state.get_remaining_data()>0:
                self.recovery_blocked = self.recovery_blocked or self.state.last_blockage_outage
                self.recovery_steps+=1
                self.recovery_energy+=float(self.state.last_action_energy_j)
            elif gained>1e-12 and self.recovery_steps>0:
                self.link_metrics['restored_events']+=1
                self.link_metrics['blockage_restored_events']+=int(self.recovery_blocked)
                self.link_metrics['recovery_delay_sum']+=self.recovery_steps
                self.link_metrics['recovery_energy_sum']+=self.recovery_energy
                self.recovery_steps=0;self.recovery_energy=0.0;self.recovery_blocked=False
        return self.state

    def _geometric_blockage_outage(self):
        """Diagnostic only: a blocked link whose mean LoS counterpart meets SNR threshold."""
        if self.params.flight_params is None:return False
        ch=self.channel
        x,y=map(float,self.state.position)
        z=float(self.state.altitude_m)
        p=ch.params
        for dev in self.state.device_list.devices:
            if dev.depleted:continue
            if ch.link_is_los((x,y,z),dev.position):continue
            dist=np.sqrt(((x-dev.position[0])*p.cell_size)**2+
                         ((y-dev.position[1])*p.cell_size)**2+(z-p.iot_height_m)**2)
            mu_los=10*np.log10(max(ch.los_norm_factor*dist**(-p.los_path_loss_exp),1e-200))
            mu_nlos=10*np.log10(max(ch.los_norm_factor*dist**(-p.nlos_path_loss_exp),1e-200))-p.nlos_excess_loss_db
            threshold=p.outage_snr_db
            if threshold is not None and mu_nlos<threshold<=mu_los:
                return True
        return False

    def comm_step(self, old_position, old_alt=None):
        if self.params.flight_params is not None:
            start=np.array([float(old_position[0]),float(old_position[1]),float(old_alt)])
            end=np.array([float(self.state.position[0]),float(self.state.position[1]),float(self.state.altitude_m)])
            positions=list(reversed(np.linspace(end,start,num=self.params.comm_steps,endpoint=False)))
        else:
            positions = list(
                reversed(np.linspace(self.state.position, old_position, num=self.params.comm_steps, endpoint=False)))

        indices = []
        device_list = self.state.device_list
        for position in positions:
            data_rate, idx = device_list.get_best_data_rate(position, self.channel)
            before = device_list.devices[idx].collected_data if idx >= 0 else 0.0
            device_list.collect_data(data_rate, idx)
            if idx >= 0:
                device = device_list.devices[idx]
                gained = float(device.collected_data - before)
                link_key = tuple(map(int, device.position))
                meta = self.channel.last_link_meta.get(link_key)
                if meta is not None:
                    group = 'los' if meta['los'] else 'nlos'
                    self.link_metrics[group+'_tx'] += 1
                    self.link_metrics[group+'_collected'] += gained
                    self.link_metrics[group+'_rate_sum'] += float(data_rate)
                    self.link_metrics['outage_tx'] += int(meta['outage'])
            if idx == -1 and any(not dev.depleted for dev in device_list.devices):
                self.link_metrics['no_service_slots'] += 1
            indices.append(idx)

        self.state.collected = device_list.get_collected_map(self.state.shape)
        self.state.device_map = device_list.get_data_map(self.state.shape)

        idx = max(set(indices), key=indices.count)
        self.state.set_device_com(idx)

        return idx

    def get_example_action(self):
        return GridActions.HOVER

    def is_in_landing_zone(self):
        return self.state.is_in_landing_zone()

    def get_collection_ratio(self):
        return self.state.get_collection_ratio()

    def get_movement_budget_used(self):
        return sum(self.state.initial_movement_budgets) - sum(self.state.movement_budgets)

    def get_max_rate(self):
        return self.channel.get_max_rate()

    def get_average_data_rate(self):
        return self.state.get_collected_data() / self.get_movement_budget_used()

    def get_cral(self):
        return self.get_collection_ratio() * self.state.all_landed

    def get_boundary_counter(self):
        return self.boundary_counter

    def get_landing_attempts(self):
        return self.landing_attempts

    def get_movement_ratio(self):
        return float(self.get_movement_budget_used()) / float(sum(self.state.initial_movement_budgets))

    def has_landed(self):
        return self.state.all_landed
