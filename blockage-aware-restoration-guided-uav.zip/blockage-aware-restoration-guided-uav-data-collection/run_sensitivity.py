"""Evaluate trained checkpoints across IoT device counts and NLoS exponents.

This script changes only the scenario configuration used for evaluation.
It never retrains or changes the optimization objective or metrics.
"""
from __future__ import annotations
import argparse
import copy
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from experiment import DDQNAgent, METHOD_SETTINGS, encode, eval_agent, summarize
from urban_environment import UAVHarvesting1UAV, load_config
from run_experiments import VALID_METHODS

ROOT=Path(__file__).resolve().parent

def make_agent(method,base_config,checkpoint,seed,device):
    env=UAVHarvesting1UAV(base_config)
    env.reset(seed+100_000)
    state=torch.load(checkpoint,map_location=device,weights_only=False)
    if method=='PPO_3D':
        from ppo_baseline import PPOAgent
        agent=PPOAgent(encode(env,False),device,seed+303)
        agent.net.load_state_dict(state['network'])
    else:
        settings=METHOD_SETTINGS[method]
        agent=DDQNAgent(encode(env,settings[2]),device,settings,seed+303,method=method)
        agent.online.load_state_dict(state['online'])
        agent.target.load_state_dict(state['target'])
    return agent

def main():
    p=argparse.ArgumentParser(description='Paper sensitivity histories; no figures')
    p.add_argument('--run-dir',type=Path,required=True,help='Existing run directory with METHOD/best.pt')
    p.add_argument('--methods',nargs='+',choices=VALID_METHODS,
                   default=['BAER_DDQN','DQN_3D','DDQN_3D','PPO_3D'])
    p.add_argument('--test-episodes',type=int,default=100)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--iot-counts',nargs='+',type=int,default=[10,20,30,40,50])
    p.add_argument('--nlos-exponents',nargs='+',type=float,default=[2,3,4,5,6])
    ns=p.parse_args()
    if ns.test_episodes<1 or not ns.iot_counts or not ns.nlos_exponents:
        p.error('episode count and sweep values must be nonempty / positive')
    out=ns.run_dir.expanduser().resolve()
    if not out.is_dir():p.error(f'not a directory: {out}')
    os.chdir(ROOT)
    torch.set_num_threads(min(4,os.cpu_count() or 4))
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    config=load_config('manhattan32_baer3d')
    agents={}
    for method in ns.methods:
        ck=out/method/'best.pt'
        if not ck.is_file():p.error(f'missing trained checkpoint: {ck}')
        agents[method]=make_agent(method,config,ck,ns.seed,device)
    folder=out/'sensitivity';folder.mkdir(parents=True,exist_ok=True)
    (folder/'sensitivity.log').write_text('Sensitivity evaluation started\n',encoding='utf-8')
    (folder/'sensitivity_config.json').write_text(json.dumps({
        'seed':ns.seed, 'test_episodes':ns.test_episodes,'methods':ns.methods,
        'iot_counts':ns.iot_counts,'nlos_exponents':ns.nlos_exponents,
        'test_seed_start':4_000_000,
        'note':'IoT size sweep fixes device count at n. NLoS sweep uses original device range 3-10.'
    },indent=2),encoding='utf-8')
    specs={
        'iot_count': [('iot_count',float(n)) for n in ns.iot_counts],
        'nlos_exponent':[('nlos_exponent',float(a)) for a in ns.nlos_exponents]
    }
    for sweep, values in specs.items():
        rows=[]; details=[]
        for dimension,value in values:
            varied=copy.deepcopy(config)
            if sweep=='iot_count':
                varied['grid_params']['device_manager']['device_count_range']=[int(value),int(value)]
            else:
                varied['physics_params']['channel_params']['nlos_path_loss_exp']=value
            for method,agent in agents.items():
                df=eval_agent(agent,varied,range(4_000_000,4_000_000+ns.test_episodes))
                row=summarize(df,method,0)
                row.pop('step',None)
                row.update(sweep=sweep,value=value)
                rows.append(row)
                df=df.copy()
                df.insert(0,'sweep_value',value)
                df.insert(0,'method',method)
                details.append(df)
                message=(f'{sweep}={value:g}, method={method}, collection_ratio={row["collection_ratio"]:.4f}, '
                         f'blockage_restored_events={row.get("blockage_restored_events",float("nan")):.3f}')
                print(message,flush=True)
                with (folder/'sensitivity.log').open('a',encoding='utf-8') as log:
                    log.write(message+'\n')
        pd.DataFrame(rows).to_csv(folder/f'{sweep}_summary.csv',index=False)
        pd.concat(details,ignore_index=True).to_csv(folder/f'{sweep}_scenarios.csv',index=False)
    print('Sensitivity histories saved under:',folder)

if __name__=='__main__':main()
