"""Reference UAV simulation components adapted from the original research code."""
