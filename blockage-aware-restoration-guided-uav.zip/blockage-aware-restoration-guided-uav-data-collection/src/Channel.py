"""Original UAV communication channel plus an opt-in geometry-based blockage profile.

legacy2d: numerical path matches the original environment's compute_rate.
urban3d: fixed per-building heights, 3-D line-of-sight test, spatially
correlated log-normal shadowing, and an optional SNR outage threshold.

The urban3d extension is a controllable research scenario, NOT a validated
3GPP TR 36.777 implementation. All added heights / thresholds must be disclosed.
"""
from __future__ import annotations
import hashlib
from pathlib import Path
import numpy as np
from src.Map.Shadowing import load_or_create_shadowing
from src.Map.Map import load_map


class ChannelParams:
    def __init__(self):
        self.cell_edge_snr = -25
        self.los_path_loss_exp = 2.27
        self.nlos_path_loss_exp = 3.64
        self.uav_altitude = 10.0
        self.cell_size = 10.0
        self.los_shadowing_variance = 2.0
        self.nlos_shadowing_variance = 5.0
        self.map_path = "res/manhattan32.png"
        # Only used by the new optional profile.
        self.blockage_model = 'legacy2d'      # 'legacy2d' or 'urban3d'
        self.iot_height_m = 1.5
        self.building_min_height_m = 8.0
        self.building_max_height_m = 25.0
        self.building_height_seed = 2026
        self.building_height_map = ''          # optional .npy, meters, HxW
        self.shadow_corr_distance_m = 20.0
        self.outage_snr_db = None             # None disables outage
        self.nlos_excess_loss_db = 0.0        # avoid double-counting NLoS loss by default


def generate_building_height_map(obstacles, seed=2026, min_height=8., max_height=25.):
    """One fixed height per 4-connected obstacle cluster (independent local RNG)."""
    from scipy.ndimage import label
    labels, count = label(obstacles.astype(bool), structure=np.array([[0,1,0],[1,1,1],[0,1,0]]))
    rng = np.random.default_rng(int(seed))
    heights = np.zeros(obstacles.shape, dtype=np.float32)
    if count:
        cluster_heights = rng.uniform(float(min_height), float(max_height), size=count)
        heights[obstacles] = cluster_heights[labels[obstacles] - 1]
    return heights


class Channel:
    def __init__(self, params: ChannelParams):
        self.params = params
        self._norm_distance = None
        self.los_norm_factor = None
        self.los_shadowing_sigma = None
        self.nlos_shadowing_sigma = None
        self.mode = getattr(params, 'blockage_model', 'legacy2d')
        if self.mode not in ('legacy2d', 'urban3d'):
            raise ValueError('blockage_model must be legacy2d or urban3d')
        self.total_shadow_map = None
        self.building_heights = None
        self._shadow_cache = {}
        self._los_cache = {}
        self._scenario_seed = 0
        self.last_link_meta = {}
        self.link_query_metrics = {}
        if self.mode == 'legacy2d':
            self.total_shadow_map = load_or_create_shadowing(params.map_path)
        else:
            obstacles = load_map(params.map_path).obstacles
            file_path = str(getattr(params, 'building_height_map', '') or '')
            if file_path:
                heights = np.load(file_path)
                if heights.shape != obstacles.shape:
                    raise ValueError('building_height_map shape does not match map')
                self.building_heights = np.where(obstacles, heights, 0.0).astype(np.float32)
            else:
                self.building_heights = generate_building_height_map(
                    obstacles, params.building_height_seed,
                    params.building_min_height_m, params.building_max_height_m)
            self._map_shape = obstacles.shape

    def reset(self, area_size, scenario_seed=None):
        self._norm_distance = np.sqrt(2) * 0.5 * area_size * self.params.cell_size
        self.los_norm_factor = 10 ** (self.params.cell_edge_snr / 10) / (
            self._norm_distance ** (-self.params.los_path_loss_exp))
        self.los_shadowing_sigma = np.sqrt(self.params.los_shadowing_variance)
        self.nlos_shadowing_sigma = np.sqrt(self.params.nlos_shadowing_variance)
        self._scenario_seed = 0 if scenario_seed is None else int(scenario_seed)
        self._shadow_cache.clear()
        self._los_cache.clear()
        self.last_link_meta.clear()
        self.link_query_metrics = {'los_link_queries': 0, 'nlos_link_queries': 0,
                                   'outage_link_queries': 0}

    def get_max_rate(self):
        dist = (abs(self.params.uav_altitude - self.params.iot_height_m)
                if self.mode == 'urban3d' else self.params.uav_altitude)
        snr = self.los_norm_factor * dist ** (-self.params.los_path_loss_exp)
        return np.log2(1 + snr)

    def _is_los3d(self, uav_pos, device_pos):
        """Deterministic ray casting with 0.25-cell horizontal sampling.

        IoT at iot_height_m, UAV at uav_altitude. A ray is blocked if any
        intervening roof reaches the ray height at that horizontal location.
        """
        ux, uy = map(float, uav_pos[:2])
        altitude = float(uav_pos[2]) if len(uav_pos)>2 else float(self.params.uav_altitude)
        dx, dy = map(float, device_pos[:2])
        key = (round(ux, 3), round(uy, 3), round(altitude, 2), round(dx, 3), round(dy, 3))
        if key in self._los_cache:
            return self._los_cache[key]
        length = float(np.hypot(ux-dx, uy-dy))
        if length < 1e-9:
            self._los_cache[key] = True
            return True
        n = max(2, int(np.ceil(length * 4)))
        fractions = np.arange(1, n, dtype=float) / n
        xx = np.rint(dx + (ux-dx)*fractions).astype(int)
        yy = np.rint(dy + (uy-dy)*fractions).astype(int)
        yy = np.clip(yy, 0, self.building_heights.shape[0]-1)
        xx = np.clip(xx, 0, self.building_heights.shape[1]-1)
        heights = self.building_heights[yy, xx]
        ray_heights = float(self.params.iot_height_m) + (
            altitude-float(self.params.iot_height_m))*fractions
        los = not bool(np.any(heights >= ray_heights))
        # Cache only modest number of unique link geometry queries.
        if len(self._los_cache) > 250_000:
            self._los_cache.clear()
        self._los_cache[key] = los
        return los

    def link_is_los(self, uav_pos, device_pos):
        """Query geometry without generating fading or changing episode RNG."""
        if self.mode == 'legacy2d':
            return not bool(self.total_shadow_map[int(round(device_pos[1])), int(round(device_pos[0])),
                                                  int(round(uav_pos[1])), int(round(uav_pos[0]))])
        return self._is_los3d(uav_pos, device_pos)

    def _shadow_db(self, uav_pos, device_pos, los):
        # One Gaussian random field per device location and LoS class per episode;
        # this is spatially correlated and *constant* on repeated visits.
        dev_x, dev_y = (int(round(device_pos[0])), int(round(device_pos[1])))
        key = (dev_x, dev_y, bool(los))
        if key not in self._shadow_cache:
            from scipy.ndimage import gaussian_filter
            token = f'{self._scenario_seed}|{dev_x}|{dev_y}|{int(los)}'.encode()
            local_seed = int.from_bytes(hashlib.sha256(token).digest()[:8], 'little')
            rng = np.random.default_rng(local_seed)
            raw = rng.standard_normal(self._map_shape)
            smooth_sigma = max(0., float(self.params.shadow_corr_distance_m) / float(self.params.cell_size))
            field = gaussian_filter(raw, sigma=smooth_sigma, mode='reflect') if smooth_sigma else raw
            field = (field-field.mean()) / max(field.std(), 1e-9)
            self._shadow_cache[key] = field
        field = self._shadow_cache[key]
        x, y = map(float, uav_pos[:2])
        x = float(np.clip(x, 0, field.shape[1]-1))
        y = float(np.clip(y, 0, field.shape[0]-1))
        x0, y0 = int(x), int(y)
        x1, y1 = min(x0+1, field.shape[1]-1), min(y0+1, field.shape[0]-1)
        fx, fy = x-x0, y-y0
        z = ((1-fx)*(1-fy)*field[y0,x0] + fx*(1-fy)*field[y0,x1] +
             (1-fx)*fy*field[y1,x0] + fx*fy*field[y1,x1])
        return float(z * (self.los_shadowing_sigma if los else self.nlos_shadowing_sigma))

    def compute_rate(self, uav_pos, device_pos):
        altitude = float(uav_pos[2]) if len(uav_pos)>2 else float(self.params.uav_altitude)
        vertical = (abs(altitude - self.params.iot_height_m)
                    if self.mode == 'urban3d' else self.params.uav_altitude)
        dist = np.sqrt(
            ((device_pos[0] - uav_pos[0]) * self.params.cell_size) ** 2 +
            ((device_pos[1] - uav_pos[1]) * self.params.cell_size) ** 2 +
            vertical ** 2)
        link_key = (int(round(device_pos[0])), int(round(device_pos[1])))
        if self.mode == 'legacy2d':
            # Preserve original random draws, exponent and SNR calculations.
            shadowed = self.total_shadow_map[int(round(device_pos[1])), int(round(device_pos[0])),
                                             int(round(uav_pos[1])), int(round(uav_pos[0]))]
            if shadowed:
                snr = self.los_norm_factor * dist ** (-self.params.nlos_path_loss_exp) * 10 ** (
                    np.random.normal(0., self.nlos_shadowing_sigma) / 10)
            else:
                snr = self.los_norm_factor * dist ** (-self.params.los_path_loss_exp) * 10 ** (
                    np.random.normal(0., self.los_shadowing_sigma) / 10)
            rate = np.log2(1 + snr)
            self.link_query_metrics['nlos_link_queries' if shadowed else 'los_link_queries'] += 1
            self.last_link_meta[link_key] = {'los':not bool(shadowed), 'outage':False,
                                            'snr_db':float(10*np.log10(max(snr,1e-300))), 'rate':float(rate)}
            return rate
        los = self._is_los3d(uav_pos, device_pos)
        exponent = self.params.los_path_loss_exp if los else self.params.nlos_path_loss_exp
        fading_db = self._shadow_db(uav_pos, device_pos, los)
        excess_db = 0.0 if los else float(self.params.nlos_excess_loss_db)
        snr = self.los_norm_factor * dist**(-exponent) * 10**((fading_db-excess_db)/10)
        snr_db = float(10*np.log10(max(snr,1e-300)))
        threshold = getattr(self.params,'outage_snr_db',None)
        outage = bool(threshold is not None and snr_db < float(threshold))
        rate = 0.0 if outage else float(np.log2(1+snr))
        self.link_query_metrics['los_link_queries' if los else 'nlos_link_queries'] += 1
        self.link_query_metrics['outage_link_queries'] += int(outage)
        self.last_link_meta[link_key] = {'los':bool(los), 'outage':outage,
                                        'snr_db':snr_db, 'rate':rate}
        return rate
