"""Paper-aligned CLI: train or evaluate with CSV histories, never plot figures."""
from __future__ import annotations
import argparse
import contextlib
import datetime as dt
import json
import os
import platform
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from experiment import Args, METHOD_SETTINGS, run, evaluate_saved_checkpoints

ROOT = Path(__file__).resolve().parent
VALID_METHODS = ('BAER_DDQN', 'DQN_3D', 'DDQN_3D', 'PPO_3D',
                 'MASK_ONLY', 'POTENTIAL_ONLY', 'FEEDBACK_ONLY', 'MASK_POTENTIAL')
PAPER_METHODS = ('BAER_DDQN', 'DQN_3D', 'DDQN_3D', 'PPO_3D')

class Tee:
    def __init__(self, *streams): self.streams = streams
    def write(self, s):
        for stream in self.streams:stream.write(s)
        return len(s)
    def flush(self):
        for stream in self.streams:stream.flush()
    def isatty(self):return False

def build_parser():
    p = argparse.ArgumentParser(description='Blockage-aware restoration-guided UAV data collection experiments')
    p.add_argument('--preset', choices=['quick', 'paper'], default='quick',
                   help='quick=smoke test; paper=1M steps/method, seed 42, 30 validation, 100 test')
    p.add_argument('--mode', choices=['train', 'evaluate'], default='train',
                   help='evaluate existing BEST checkpoints instead of training')
    p.add_argument('--methods', nargs='+', choices=VALID_METHODS,
                   help='methods to run; default is the proposed method for quick and all four for paper')
    p.add_argument('--output', type=Path, help='run directory; required for --mode evaluate')
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--steps', type=int, help='training environment steps per method')
    p.add_argument('--prefill', type=int, help='prefill steps for DQN-family only')
    p.add_argument('--batch', type=int)
    p.add_argument('--replay', type=int)
    p.add_argument('--eval-every', type=int, help='validation interval in training steps')
    p.add_argument('--eval-episodes', type=int)
    p.add_argument('--test-episodes', type=int)
    p.add_argument('--trace-count', type=int,
                   help='number of test scenario trajectories saved per method')
    p.add_argument('--beta', type=float, default=0.15)
    p.add_argument('--potential-cap', type=float, default=12.0)
    p.add_argument('--ppo-rollout', type=int)
    p.add_argument('--ppo-epochs', type=int)
    p.add_argument('--ppo-minibatch', type=int)
    p.add_argument('--no-step-logging', action='store_true',
                   help='disable compressed per-training-step CSV to reduce disk space')
    return p

def make_args(opts):
    if opts.preset == 'paper':
        defaults = dict(steps=1_000_000, prefill=25_000, batch=128, replay=50_000,
                        eval_every=50_000, eval_episodes=30, test_episodes=100,
                        trace_count=100, ppo_rollout=512, ppo_epochs=4,
                        ppo_minibatch=64)
    else:
        defaults = dict(steps=64, prefill=12, batch=8, replay=96,
                        eval_every=32, eval_episodes=2, test_episodes=2,
                        trace_count=1, ppo_rollout=16, ppo_epochs=2,
                        ppo_minibatch=8)
    for name in defaults:
        provided = getattr(opts, name)
        if provided is not None: defaults[name] = provided
    if opts.mode == 'train' and not (0 < defaults['prefill'] < defaults['steps']):
        raise SystemExit('ERROR: requires 0 < --prefill < --steps')
    if defaults['replay'] < max(defaults['prefill'], defaults['batch']):
        raise SystemExit('ERROR: replay capacity must be >= prefill and batch')
    if min(defaults['eval_every'],defaults['eval_episodes'],defaults['test_episodes']) < 1:
        raise SystemExit('ERROR: eval interval and episode counts must be positive')
    if not (0 <= defaults['trace_count'] <= defaults['test_episodes']):
        raise SystemExit('ERROR: trace-count must be between 0 and test-episodes')
    methods = tuple(opts.methods or (PAPER_METHODS if opts.preset == 'paper' else ('BAER_DDQN',)))
    if len(set(methods)) != len(methods):
        raise SystemExit('ERROR: duplicate methods supplied')
    if opts.output is None:
        if opts.mode == 'evaluate':
            raise SystemExit('ERROR: --mode evaluate requires --output pointing to checkpoints')
        timestamp = dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        out = ROOT / 'runs' / f'{opts.preset}_seed{opts.seed}_{timestamp}'
    else:
        out = opts.output.expanduser().resolve()
    if opts.mode == 'train' and out.exists() and any(out.iterdir()):
        raise SystemExit(f'ERROR: output directory already contains files: {out}. Pick a new --output.')
    if opts.mode == 'evaluate' and not out.is_dir():
        raise SystemExit(f'ERROR: output directory does not exist: {out}')
    return Args(**defaults, seed=opts.seed, beta=opts.beta,
                potential_cap=opts.potential_cap, train_methods=methods,
                output=str(out), log_train_steps=not opts.no_step_logging)

def main():
    opts = build_parser().parse_args()
    args = make_args(opts)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    os.chdir(ROOT)  # original environment uses project-relative paths for map assets
    if opts.mode == 'train':
        config = {
            'paper_title': 'Blockage-Aware Restoration-Guided Reinforcement Learning for UAV Data Collection',
            'experiment': 'Manhattan32 3-D, single UAV',
            'run_mode': opts.mode, 'preset': opts.preset,
            'args': vars(args), 'python': platform.python_version(),
            'numpy': np.__version__, 'pandas': pd.__version__,
            'torch': torch.__version__, 'cuda_available': torch.cuda.is_available(),
            'note': 'BAER_DDQN is the original internal identifier for the proposed method.'}
        (out/'run_config.json').write_text(json.dumps(config,indent=2,default=list),encoding='utf-8')
    with (out/'console.log').open('a',encoding='utf-8') as fd:
        with contextlib.redirect_stdout(Tee(sys.stdout,fd)):
            print(f'Run directory: {out}',flush=True)
            print(f'Mode: {opts.mode}; preset: {opts.preset}; methods: {list(args.train_methods)}',flush=True)
            print(f'Torch device: {"CUDA" if torch.cuda.is_available() else "CPU"}',flush=True)
            print('Seed:',args.seed, '| environment training steps per method:',args.steps,flush=True)
            if opts.mode == 'evaluate':
                summary = evaluate_saved_checkpoints(args)
            else:
                summary = run(args)
            print('\nSummary saved:',out/'comparison_summary.csv',flush=True)
            print(summary.to_string(index=False),flush=True)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
