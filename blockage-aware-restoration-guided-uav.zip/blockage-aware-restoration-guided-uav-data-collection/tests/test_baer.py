"""Deterministic regression checks; no training. Run: python test_baer.py"""
from __future__ import annotations
import random
import numpy as np
from urban_environment import UAVHarvesting1UAV,load_config
from src.BlockageRestoration import BlockageRestoration

cfg=load_config('manhattan32_baer3d')
env=UAVHarvesting1UAV(cfg)
s=env.reset(seed=42)
g=env.physics.flight_graph
assert s.altitude_m==10. and g.num_levels==5
assert len(env.actions)==8
assert g.landing_energy((int(s.position[0]),int(s.position[1]),0))>=g.costs[4]

# Vertical UAV position must enter BOTH geometric LoS classification and channel range.
ch=env.physics.channel
found=None
for d in s.device_list.devices:
    for y in range(g.height):
        for x in range(g.width):
            if not g.valid(x,y,0) or not g.valid(x,y,4):continue
            low=ch.link_is_los((x,y,10.),d.position)
            high=ch.link_is_los((x,y,30.),d.position)
            if not low and high:
                found=(x,y,d.position);break
        if found:break
    if found:break
assert found, 'Expected a location where 3D ascent restores geometric LoS'
x,y,d=found
assert not ch.link_is_los((x,y,10.),d) and ch.link_is_los((x,y,30.),d)
print('LoS restoration geometry found:',found)

# Same horizontal cell, more height changes link distance/SNR.
ch.compute_rate((x,y,10),d);s1=ch.last_link_meta[tuple(map(int,d))]['snr_db']
ch.compute_rate((x,y,30),d);s2=ch.last_link_meta[tuple(map(int,d))]['snr_db']
assert s1!=s2

# Never fly through rooftops; never fly into NFZ or outside altitude bounds.
for k in range(5):
    assert not any(g.valid(x,y,k) for y,x in np.argwhere((g.heights>=g.height_levels[k]-g.clearance)&(~g.nfz)))

# Deterministic scenario and transfer accounting, including action UP/DOWN.
env.reset(seed=42)
for a in (6,6,1,0,7,7,5):
    env.step(a)
    if env.state.terminal:break
m=env.metrics()
assert np.isclose(m['energy_initial_j']-m['energy_remaining_j'],m['energy_used_j'])
assert np.isclose(m['los_collected']+m['nlos_collected'],m['collected_data'],atol=1e-6)
assert 0<=m['collection_ratio']<=1

# Landing must require base altitude, landing-zone XY and sufficient energy.
env.reset(seed=42)
start=tuple(env.state.position)
assert env.state.is_in_landing_zone()
env.step(6)
assert not env.state.is_in_no_fly_zone()
_,_,done=env.step(4)
assert not done and not env.state.landed
_,_,done=env.step(7)
_,_,done=env.step(4)
assert done and env.state.landed

# Returned masks never all-false and mask safe-action path under reserve budget.
env.reset(seed=12345)
planner=BlockageRestoration(env)
random.seed(12345)
for step in range(30):
    if env.state.terminal:break
    mask=planner.safe_mask()
    assert mask.shape==(8,) and mask.any()
    phi=planner.potential()
    assert np.isfinite(phi) and -planner.max_cost<=phi<=0
    actions=np.flatnonzero(mask)
    a=int(random.choice(actions))
    env.step(a)
print('PASS: 3D collision, LoS recovery geometry, energy, reward, safe mask, potential.')
