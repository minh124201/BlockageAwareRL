"""Train DQN, DDQN, PPO and blockage-aware restoration-guided DDQN.

Strict parity: same urban3d simulator, 8 actions, CNN architecture, replay,
train/evaluation seeds, gamma, Adam and learning budget. Differences are
controlled by methods: radio feedback, geometry-specific potential shaping,
and energy/landing-feasibility masking of both behavior and Double-DQN target.

Use run_experiments.py to train and export CSV histories.
"""
from __future__ import annotations
import argparse, copy, json, os, random, time
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from tqdm.auto import tqdm
from src.StateUtils import pad_centered
from urban_environment import UAVHarvesting1UAV, load_config
from src.BlockageRestoration import BlockageRestoration
from history_logging import StepCSVWriter, get_step_record

METHOD_SETTINGS = {
    'DQN_3D':(False,False,False),
    'DDQN_3D':(False,False,False),
    'MASK_ONLY':(True,False,False),
    'POTENTIAL_ONLY':(False,True,False),
    'FEEDBACK_ONLY':(False,False,True),
    'MASK_POTENTIAL':(True,True,False),
    'BAER_DDQN':(True,True,True),
}

@dataclass
class Args:
    steps:int=100_000
    prefill:int=25_000
    batch:int=128
    replay:int=50_000
    eval_every:int=10_000
    eval_episodes:int=30
    test_episodes:int=100
    seed:int=42
    beta:float=0.15
    potential_cap:float=12.0
    train_methods:tuple=('DDQN_3D','BAER_DDQN')
    output:str='runs_baer3d'
    trace_count:int=3  # keep trajectories for first N held-out test scenarios
    log_train_steps:bool=True  # one genuine env.step per compressed CSV row
    ppo_rollout:int=512
    ppo_epochs:int=4
    ppo_minibatch:int=64


def seed_all(seed):
    random.seed(int(seed));np.random.seed(int(seed));torch.manual_seed(int(seed))
    if torch.cuda.is_available():torch.cuda.manual_seed_all(int(seed))


def encode(env, include_feedback=True):
    s=env.state
    base=s.get_boolean_map().astype(np.float32)
    remain=s.get_float_map().astype(np.float32)
    heights=(env.physics.channel.building_heights / 30.0).astype(np.float32)
    terrain=pad_centered(s,heights[:,:,None],0).astype(np.float32)
    ch=np.concatenate([base,remain,terrain],axis=-1)
    p=int(env.global_pool);L=int(env.local_width)
    h,w,c=ch.shape;gh,gw=h//p,w//p
    g=ch[:gh*p,:gw*p,:].reshape(gh,p,gw,p,c).mean(axis=(1,3)).transpose(2,0,1)
    local=ch[(h-L)//2:(h+L)//2,(w-L)//2:(w+L)//2,:].transpose(2,0,1)
    graph=env.physics.flight_graph
    scal=np.array([s.movement_budget/env.max_budget,
                   s.energy_j/max(1.,s.initial_energy_j),
                   (s.altitude_m-graph.min_height)/(graph.height_levels[-1]-graph.min_height),
                   s.last_no_service_fraction if include_feedback else 0.0,
                   s.last_collection_fraction if include_feedback else 0.0],dtype=np.float32)
    return (np.ascontiguousarray(g,dtype=np.float16),
            np.ascontiguousarray(local,dtype=np.float16),scal)

class GlobalLocalQNet(nn.Module):
    """Exact Global-Local CNN topology (2 conv16 kernel5/branch + 3 dense256), 8 outputs."""
    def __init__(self, obs, n_actions=8):
        super().__init__()
        ch=obs[0].shape[0]
        def branch():
            return nn.Sequential(nn.Conv2d(ch,16,5),nn.ReLU(),
                                 nn.Conv2d(16,16,5),nn.ReLU(),nn.Flatten())
        self.global_net=branch();self.local_net=branch()
        with torch.no_grad():
            ng=self.global_net(torch.zeros((1,)+obs[0].shape)).shape[-1]
            nl=self.local_net(torch.zeros((1,)+obs[1].shape)).shape[-1]
        self.output=nn.Sequential(nn.Linear(ng+nl+len(obs[2]),256),nn.ReLU(),
                                  nn.Linear(256,256),nn.ReLU(),
                                  nn.Linear(256,256),nn.ReLU(),nn.Linear(256,n_actions))
        for m in self.modules():
            if isinstance(m,(nn.Conv2d,nn.Linear)):
                nn.init.xavier_uniform_(m.weight);nn.init.zeros_(m.bias)

    def forward(self,g,l,scal):
        return self.output(torch.cat((self.global_net(g),self.local_net(l),scal),dim=1))

class ReplayBuffer:
    def __init__(self,capacity,obs,seed):
        self.size=0;self.pos=0;self.capacity=capacity
        self.rng=np.random.default_rng(seed)
        self.obs=[np.empty((capacity,)+v.shape,dtype=v.dtype) for v in obs]
        self.next=[np.empty((capacity,)+v.shape,dtype=v.dtype) for v in obs]
        self.a=np.empty(capacity,np.int64);self.r=np.empty(capacity,np.float32)
        self.done=np.empty(capacity,np.bool_)
        self.next_mask=np.empty((capacity,8),dtype=np.bool_)

    def add(self,obs,act,reward,nxt,done,next_mask):
        ix=self.pos
        for j in range(3):
            self.obs[j][ix]=obs[j];self.next[j][ix]=nxt[j]
        self.a[ix]=act;self.r[ix]=reward;self.done[ix]=done
        self.next_mask[ix]=next_mask
        self.pos=(ix+1)%self.capacity
        self.size=min(self.capacity,self.size+1)

    def sample(self,batch,device):
        ids=self.rng.choice(self.size,batch,replace=False)
        ids[0]=(self.pos-1)%self.capacity  # upstream replay includes most recent transition
        def convert(x):return torch.as_tensor(x[ids],device=device)
        states=[convert(x).float() for x in self.obs]
        next_states=[convert(x).float() for x in self.next]
        return states,convert(self.a),convert(self.r),next_states,convert(self.done),convert(self.next_mask)

class DDQNAgent:
    def __init__(self,obs,device,settings,seed,gamma=0.95,tau=0.005,lr=3e-5,temp=0.1,method='DDQN_3D'):
        seed_all(seed)
        self.online=GlobalLocalQNet(obs).to(device)
        self.target=GlobalLocalQNet(obs).to(device)
        self.target.load_state_dict(self.online.state_dict())
        self.optimizer=torch.optim.Adam(self.online.parameters(),lr=lr,amsgrad=True,eps=1e-7)
        self.device=device;self.gamma=gamma;self.tau=tau;self.temp=temp
        self.mask,self.shape,self.feedback=settings
        self.method=method
        self.updates=0

    @torch.no_grad()
    def action(self,obs,rng,mask=None,greedy=False,target=False):
        model=self.target if target else self.online
        q=model(*[torch.as_tensor(x[None],device=self.device).float() for x in obs])[0]
        if self.mask and mask is not None:
            m=torch.as_tensor(mask,device=self.device,dtype=torch.bool)
            q=q.masked_fill(~m,-1e9)
        if greedy:return int(q.argmax().item())
        probs=torch.softmax(q/self.temp,dim=-1).cpu().numpy().astype(float)
        probs=probs/max(1e-12,float(probs.sum()))
        return int(rng.choice(8,p=probs))

    def update(self,replay,batch):
        obs,act,reward,nxt,done,mask=replay.sample(batch,self.device)
        with torch.no_grad():
            online_next=self.online(*nxt)
            if self.mask: online_next=online_next.masked_fill(~mask,-1e9)
            if self.method=='DQN_3D':
                # True vanilla DQN: target network both selects and evaluates max Q.
                target_next=self.target(*nxt)
                if self.mask:target_next=target_next.masked_fill(~mask,-1e9)
                q_next=target_next.max(dim=1).values
            else:
                # Double DQN: online network selects, target network evaluates.
                argmax=online_next.argmax(1,keepdim=True)
                q_next=self.target(*nxt).gather(1,argmax).squeeze(1)
            target=reward+self.gamma*(1.-done.float())*q_next
        value=self.online(*obs).gather(1,act[:,None]).squeeze(1)
        loss=(value-target).square().mean()/8.0
        self.optimizer.zero_grad(set_to_none=True)
        loss.backward()
        self.optimizer.step()
        with torch.no_grad():
            for t,o in zip(self.target.parameters(),self.online.parameters()):
                t.mul_(1-self.tau).add_(o,alpha=self.tau)
        self.updates+=1
        return float(loss.item())


def eval_agent(agent,config,seeds,trajectory_dir=None,scenario_dir=None,trace_count=0):
    """Paired evaluation; optionally export full scene and action trace of first N seeds.

    Normal evaluation does NOT access hidden future channel. Tracing is read-only.
    """
    from trajectory_history import snapshot,step_record,save_scenario,save_trajectory
    saved_rng=np.random.get_state();saved_py=random.getstate()
    env=UAVHarvesting1UAV(config)
    planner=BlockageRestoration(env) if agent.mask else None
    rows=[]
    try:
        for index,sc in enumerate(seeds):
            env.reset(int(sc))
            if planner is not None:planner.reset(env)
            trace=trajectory_dir is not None and index<int(trace_count)
            if trace:save_scenario(env,int(sc),scenario_dir)
            steps=[];done=False
            while not done:
                observation=encode(env,include_feedback=agent.feedback)
                mask=planner.safe_mask() if planner is not None else None
                action=agent.action(observation,None,mask,greedy=True,target=True)
                if trace:before=snapshot(env)
                _,reward,done=env.step(action)
                if trace:
                    after=snapshot(env)
                    steps.append(step_record(before,after,env,sc,
                                             getattr(agent,'method','PPO_3D'),len(steps)+1,action,reward))
            if trace:
                save_trajectory(int(sc),getattr(agent,'method','PPO_3D'),env,
                                steps,scenario_dir,trajectory_dir)
            m=env.metrics();m['scenario_seed']=int(sc)
            rows.append(m)
    finally:
        np.random.set_state(saved_rng);random.setstate(saved_py)
    return pd.DataFrame(rows)


def save_checkpoint(agent,path,step,seed,method):
    """Explicit PPO vs Q-agent checkpoint types; same artifact naming."""
    if method=='PPO_3D':
        torch.save({'network':agent.net.state_dict(),'step':step,'seed':seed,
                    'method':method,'algorithm':'categorical_ppo'},path)
    else:
        torch.save({'online':agent.online.state_dict(),
                    'target':agent.target.state_dict(),
                    'step':step,'seed':seed,'method':method,
                    'settings':METHOD_SETTINGS[method]},path)

def summarize(df,method,steps):
    result={'method':method,'step':int(steps)}
    for name in ['reward','collection_ratio','cral','landed','steps_used',
                 'boundary_counter','landing_attempts','collected_data','total_data',
                 'energy_used_j','energy_remaining_j','no_service_slots',
                 'los_tx','nlos_tx','los_link_queries','nlos_link_queries',
                 'outage_link_queries','restored_events','recovery_delay_sum',
                 'blockage_no_service_steps','blockage_restored_events',
                 'iot_total','iot_fully_collected','iot_success_ratio',
                 'iot_partially_collected']:
        if name in df:result[name]=float(df[name].mean())
    return result


def train_one(method,cfg,args,device):
    if method not in METHOD_SETTINGS: raise ValueError(f'Unknown method: {method}')
    settings=METHOD_SETTINGS[method]
    mask_enabled,shape_enabled,feedback_enabled=settings
    seed_all(args.seed)
    random_actions=np.random.default_rng(args.seed+101)
    buffer_seed=args.seed+202
    env=UAVHarvesting1UAV(cfg)
    env.reset(args.seed+100_000)
    obs=encode(env,feedback_enabled)
    agent=DDQNAgent(obs,device,settings,args.seed+303,method=method)
    replay=ReplayBuffer(args.replay,obs,buffer_seed)
    planner=BlockageRestoration(env,max_cost=args.potential_cap) if any(settings[:2]) else None
    out=Path(args.output)/method
    out.mkdir(parents=True,exist_ok=True)
    history_writer=(StepCSVWriter(out/'train_steps.csv.gz') if args.log_train_steps else None)
    step=0;episodes=0;loss=0.0;best_cral=-float('inf')
    train_rows=[];eval_rows=[];eval_scenarios=[]
    start=time.time()
    print(f'\n--- {method}: {args.steps:,} steps (prefill {args.prefill:,}) ---',flush=True)
    for phase in ('prefill','train'):
        limit=args.prefill if phase=='prefill' else args.steps
        bar=tqdm(total=limit,initial=min(step,limit),desc=f'{method} {phase}',unit='step')
        while step<limit:
            ep_seed=args.seed+(100_000 if phase=='prefill' else 1_000_000)+episodes
            env.reset(ep_seed)
            if planner is not None:planner.reset(env)
            done=False
            while not done and step<limit:
                obs=encode(env,feedback_enabled)
                phi=(planner.potential() if shape_enabled and phase=='train' else 0.0)
                safe=planner.safe_mask() if mask_enabled and phase=='train' else None
                a=(int(random_actions.integers(0,8)) if phase=='prefill' else
                   agent.action(obs,random_actions,safe))
                prev_collected=float(env.state.get_collected_data())
                _,base_r,done=env.step(a)
                nextobs=encode(env,feedback_enabled)
                phi_next=(planner.potential() if shape_enabled and not done and phase=='train' else 0.0)
                learning_r=base_r+(args.beta*(agent.gamma*phi_next-phi) if shape_enabled and phase=='train' else 0.0)
                if mask_enabled:
                    nmask=(planner.safe_mask() if not done else np.ones(8,dtype=np.bool_))
                else:nmask=np.ones(8,dtype=np.bool_)
                replay.add(obs,a,learning_r,nextobs,done,nmask)
                step+=1
                if phase=='train' and replay.size>=args.batch:
                    loss=agent.update(replay,args.batch)
                if history_writer is not None:
                    history_writer.write(get_step_record(
                        env,method,phase,step,episodes+1,ep_seed,a,
                        base_r,prev_collected,loss,done))
                    if step%10000==0:history_writer.flush()
                bar.update(1)
            episodes+=1
            if phase=='train':
                m=env.metrics();m.update(step=step,episode=episodes,method=method,
                                         loss=loss,updates=agent.updates,
                                         episode_complete=bool(done))
                train_rows.append(m)
                if step>=args.eval_every and (step//args.eval_every>len(eval_rows) or step>=args.steps):
                    seeds=range(3_000_000,3_000_000+args.eval_episodes)
                    table=eval_agent(agent,cfg,seeds)
                    row=summarize(table,method,step);eval_rows.append(row)
                    detail=table.copy();detail.insert(0,'step',step)
                    detail.insert(0,'method',method);eval_scenarios.append(detail)
                    save_checkpoint(agent,out/'last.pt',step,args.seed,method)
                    if row['cral']>best_cral:
                        best_cral=row['cral']
                        save_checkpoint(agent,out/'best.pt',step,args.seed,method)
                    pd.DataFrame(train_rows).to_csv(out/'train.csv',index=False)
                    pd.DataFrame(eval_rows).to_csv(out/'eval_30.csv',index=False)
                    pd.concat(eval_scenarios,ignore_index=True).to_csv(out/'eval_scenarios.csv',index=False)
                    bar.set_postfix(CR=f'{row["collection_ratio"]:.3f}',CRAL=f'{row["cral"]:.3f}')
        bar.close()
    if history_writer is not None:history_writer.close()
    print(f'{method} trained {step:,} steps, updates {agent.updates:,}, wall={time.time()-start:.1f}s')
    checkpoint=torch.load(out/'best.pt',map_location=device,weights_only=False)
    agent.online.load_state_dict(checkpoint['online']);agent.target.load_state_dict(checkpoint['target'])
    test=eval_agent(agent,cfg,range(4_000_000,4_000_000+args.test_episodes),
                    trajectory_dir=out/'trajectories',scenario_dir=Path(args.output)/'scenarios',
                    trace_count=args.trace_count)
    test.to_csv(out/'final_test.csv',index=False)
    result=summarize(test,method,checkpoint['step'])
    result.update(train_steps=step,gradient_updates=agent.updates,wall_seconds=time.time()-start,train_steps_prefill=args.prefill)
    (out/'config_used.json').write_text(json.dumps({**vars(args),'method':method,'method_settings':settings,
          'simulation_config':cfg},indent=2,default=list),encoding='utf8')
    print('TEST',result,flush=True)
    return result


def evaluate_saved_checkpoints(args):
    """No re-training. Re-evaluate BEST checkpoints already present under output/METHOD.

    Can regenerate per-IoT, scenario and trajectory histories from old DDQN/BAER best.pt.
    """
    torch.set_num_threads(min(4,os.cpu_count() or 4))
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    cfg=load_config('manhattan32_baer3d')
    root=Path(args.output);root.mkdir(exist_ok=True,parents=True)
    results=[];raw=[]
    for method in args.train_methods:
        ckpath=root/method/'best.pt'
        if not ckpath.exists():raise FileNotFoundError(f'Checkpoint missing: {ckpath}')
        env=UAVHarvesting1UAV(cfg);env.reset(args.seed+100_000)
        ck=torch.load(ckpath,map_location=device,weights_only=False)
        if method=='PPO_3D':
            from ppo_baseline import PPOAgent
            agent=PPOAgent(encode(env,False),device,args.seed+303,epochs=args.ppo_epochs,
                           minibatch=args.ppo_minibatch)
            agent.net.load_state_dict(ck['network'])
        else:
            settings=METHOD_SETTINGS[method]
            agent=DDQNAgent(encode(env,settings[2]),device,settings,args.seed+303,method=method)
            agent.online.load_state_dict(ck['online']);agent.target.load_state_dict(ck['target'])
        test=eval_agent(agent,cfg,range(4_000_000,4_000_000+args.test_episodes),
                        trajectory_dir=root/method/'trajectories',scenario_dir=root/'scenarios',
                        trace_count=args.trace_count)
        (root/method).mkdir(parents=True,exist_ok=True)
        test.to_csv(root/method/'final_test.csv',index=False)
        d=test.copy();d.insert(0,'method',method);raw.append(d)
        results.append(summarize(test,method,ck['step']))
    pd.concat(raw,ignore_index=True).to_csv(root/'test_all_methods.csv',index=False)
    summary=pd.DataFrame(results);summary.to_csv(root/'comparison_summary.csv',index=False)
    return summary

def run(args):
    args.train_methods=tuple(args.train_methods)
    assert 0<args.prefill<args.steps
    assert args.replay>=args.prefill and args.replay>=args.batch
    if not (Path.cwd()/'src/Flight3D.py').exists():
        os.chdir(Path(__file__).resolve().parent)
    torch.set_num_threads(min(4,os.cpu_count() or 4))
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    cfg=load_config('manhattan32_baer3d')
    out=Path(args.output)
    out.mkdir(exist_ok=True,parents=True)
    results=[]
    for method in args.train_methods:
        if method=='PPO_3D':
            from ppo_baseline import train_ppo
            results.append(train_ppo(cfg,args,device))
        else:
            results.append(train_one(method,cfg,args,device))
        pd.DataFrame(results).to_csv(out/'comparison_summary.csv',index=False)
    comparison=pd.DataFrame(results)
    # Held-out pairing across all requested methods. No post-test checkpoint tuning.
    scenario_tables=[]
    for method in args.train_methods:
        f=out/method/'final_test.csv'
        if f.exists():
            d=pd.read_csv(f);d.insert(0,'method',method)
            scenario_tables.append(d)
    if scenario_tables:
        pd.concat(scenario_tables,ignore_index=True).to_csv(out/'test_all_methods.csv',index=False)
    print('\n',comparison.to_string(index=False))
    return comparison
