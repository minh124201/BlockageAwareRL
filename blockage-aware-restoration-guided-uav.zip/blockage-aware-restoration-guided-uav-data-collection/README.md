# Blockage-Aware Restoration-Guided Reinforcement Learning for UAV Data Collection

**Python source and experiment histories for the corresponding research manuscript.**

This repository packages the provided **single-UAV 3-D Manhattan32** simulation and the PyTorch training/evaluation path. The proposed model combines (1) geometry-aware communication restoration potential, (2) estimated return-feasibility action screening, and (3) recent communication feedback. It compares against **DQN, DDQN, and PPO**. Source algorithms, channel/energy surrogate, original scenario generation and fixed seed conventions are retained; this repository does **not** generate figures.

> **Method naming:** the manuscript title uses *Blockage-Aware Restoration-Guided Reinforcement Learning*. The original implementation identifies the proposed method as `BAER_DDQN` (Blockage-Aware Energy-Feasible Restoration DDQN). These refer to the **same provided implementation**, not separate algorithms. Baselines are `DQN_3D`, `DDQN_3D`, and `PPO_3D`. The additional identifiers `MASK_ONLY`, `POTENTIAL_ONLY`, `FEEDBACK_ONLY` and `MASK_POTENTIAL` are exploratory configurations, not figures or proven ablation results.

## 1. Clone, install and test

Requires Python **3.10–3.12** (recommended), `pip` and approximately enough RAM for the replay buffer (full training is much larger than a quick test). Linux, Windows PowerShell and GPU-enabled Kaggle are supported in principle. GPU availability is detected automatically.

```bash
git clone https://github.com/YOUR_USERNAME/blockage-aware-restoration-guided-uav-data-collection.git
cd blockage-aware-restoration-guided-uav-data-collection
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m tests.test_baer
python -m tests.test_blockage
```

Replace `YOUR_USERNAME` with your actual GitHub username after publishing. For NVIDIA GPU, install an appropriate CUDA-enabled PyTorch wheel first using [the official PyTorch installer](https://pytorch.org/get-started/locally/), then the remaining requirements. The supplied `requirements.txt` may otherwise install CPU PyTorch.

## 2. Quick verification (default, 64 environment steps)

```bash
python run_experiments.py --preset quick --methods BAER_DDQN
```

To smoke-test the four paper methods:

```bash
python run_experiments.py --preset quick --methods BAER_DDQN DQN_3D DDQN_3D PPO_3D
```

This creates a **new timestamped** directory under `runs/`, prints training progress and final test metrics, and saves `console.log`, `run_config.json`, CSV histories and checkpoints. **Quick runs are not paper results** and must not be quoted as the published performance.

## 3. Paper-aligned training (1000000 environment steps per method)

```bash
python run_experiments.py --preset paper
```

The command trains all four methods using the same reference code, with seed `42`, DQN-family prefill `25,000`, replay `50,000`, batch `128`, validation every `50,000` training steps on `30` fixed scenarios, a held-out test set of `100` scenarios and up to `100` test trajectories per method. PPO uses rollout `512`, `4` epochs, minibatch `64` and **no DQN prefill**. Preset settings follow the provided notebook and manuscript.

The command is computationally intensive and may require significant GPU time and disk space. Set an explicit location if useful:

```bash
python run_experiments.py --preset paper --output runs/paper_seed42
```

To train just the proposed method:

```bash
python run_experiments.py --preset paper --methods BAER_DDQN
```

Parameter overrides are supported, e.g. `--seed 123 --steps 100000 --trace-count 10`. Each training run refuses to write into a nonempty output folder, preventing accidental overwriting. Check `python run_experiments.py --help` for all options.

## 4. Evaluation without retraining

Provide the exact folder printed by the training command. This loads each `METHOD/best.pt`, evaluates on the held-out test scenarios, and saves updated `final_test.csv`, `comparison_summary.csv`, paired scenario histories and trajectory traces.

```bash
python run_experiments.py --mode evaluate --preset paper --output runs/paper_seed42
```

Use `--methods BAER_DDQN` if only that checkpoint exists. **Checkpoints are not included in this source ZIP**; train the models first or supply your own compatible checkpoints. `--mode evaluate` does not reconstruct training histories if training was never performed.

## 5. Figure 3 data: fixed IoT counts and NLoS attenuation (CSV only)

```bash
python run_sensitivity.py --run-dir runs/paper_seed42
```

The script loads trained best checkpoints and evaluates them with **10, 20, 30, 40, 50 IoT devices** (count fixed for each condition), then NLoS path-loss exponents **2, 3, 4, 5, 6**, keeping the standard training-range device count for the NLoS sweep. The same held-out seeds are used across methods within each setting. It saves raw paired scenario records and summarized CSV files without changing training, network architecture, reward, or simulator physics code. **These sensitivity runs are new evaluation wrappers around the supplied code**; verify the exact scenario protocol against the manuscript if reproducing a previously generated plot.

If only the proposed checkpoint exists, run:

```bash
python run_sensitivity.py --run-dir runs/paper_seed42 --methods BAER_DDQN
```

## 6. Output histories

```text
runs/paper_seed42/
├── console.log                      # live text summary and messages
├── run_config.json                  # args, environment and library versions
├── comparison_summary.csv           # per-method test averages
├── test_all_methods.csv             # paired held-out scenario records
├── scenarios/scenario_4000000.json  # actual buildings, UAV start, IoT, landing cells
├── BAER_DDQN/                      # other METHOD/ folders have same format
│   ├── train_steps.csv.gz           # each training environment step
│   ├── train.csv                    # per completed/partial episode training metrics
│   ├── eval_30.csv                  # validation summaries (filename retained from source)
│   ├── eval_scenarios.csv           # individual validation scenarios
│   ├── final_test.csv               # final held-out scenario metrics
│   ├── config_used.json             # method and simulation settings
│   ├── best.pt                      # best checkpoint by landing-adjusted collection
│   ├── last.pt                      # last validation checkpoint
│   └── trajectories/
│       ├── trajectory_BAER_DDQN_seed4000000.csv  # every test movement
│       └── devices_BAER_DDQN_seed4000000.csv     # final per-device data
└── sensitivity/
    ├── iot_count_summary.csv
    ├── iot_count_scenarios.csv
    ├── nlos_exponent_summary.csv
    ├── nlos_exponent_scenarios.csv
    └── sensitivity_config.json
```

`collection_ratio` is total collected **normalized data units** divided by the initial total available data. `energy_used_j` is **simulated/surrogate** consumption from nominal power and a fixed step duration, not measured aircraft power. `cral` denotes collection ratio multiplied by the successful-landing indicator. The fields `blockage_restored_events` and `restored_events` are event counts, **not percentages**; calculate a blockage recovery rate only after defining the appropriate number of blockage events as the denominator. Avoid claiming guaranteed return from the action screen, which relies on separate estimates and has a fallback.

**No plotting scripts, notebook dependencies, or Matplotlib are required for this release.** PNG files under `res/` are essential **simulation map inputs**, not figures.

## 7. Source organization

```text
run_experiments.py       training/checkpoint evaluation CLI
run_sensitivity.py       evaluation-only IoT-count/NLoS sweeps
experiment.py            reference DQN/DDQN/proposed trainer, CNN and replay
ppo_baseline.py          categorical PPO baseline
urban_environment.py    one-UAV interface, original reward/channel interface
history_logging.py      streaming CSV step-level logging
trajectory_history.py   scenario metadata and trajectory history, no plotting
src/                    geometry, channel, physics, UAV state and return screening
config/                 original JSON configurations
res/                    original map inputs and shadowing cache
tests/                  deterministic 3-D and channel regression checks
```

## 8. Reproducibility and attribution

- Retained algorithm implementations and experimental config are from the **provided ZIP and notebook**. Module names were normalized; legacy TensorFlow training/plotting code was omitted. The 2020 upstream project from which some simulator components originated is described in the license and source references: [Bayerlein et al., UAV data harvesting](https://ieeexplore.ieee.org/document/9437338).
- Source code is **not pre-populated with 1M-step results**. Running it generates new logs; reproduction depends on PyTorch/CUDA versions, hardware and RNG implementation. The manuscript's approximate numerical results should be **verified**, not assumed from a quick test.
- `best.pt` files are PyTorch pickle checkpoints: load only checkpoints you trust. `runs/` is ignored by Git to avoid committing large results/checkpoints accidentally; share selected CSV/weights intentionally when permitted by repository/file-size constraints.
- The provided `LICENSE` retains the BSD-3-Clause notices for the upstream code. Confirm rights and authorship for your added research contributions before publishing the repository.
