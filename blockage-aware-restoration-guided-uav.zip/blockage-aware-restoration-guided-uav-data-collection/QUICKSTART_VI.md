# Hướng dẫn chạy nhanh (tiếng Việt)

**Tên repo:** `blockage-aware-restoration-guided-uav-data-collection`  
**Tên bài báo:** *Blockage-Aware Restoration-Guided Reinforcement Learning for UAV Data Collection*  
**Mã phương pháp trong code:** `BAER_DDQN` (giữ mã nhận dạng nội bộ gốc để đối chiếu các thí nghiệm).

## Cài đặt

```bash
git clone https://github.com/YOUR_USERNAME/blockage-aware-restoration-guided-uav-data-collection.git
cd blockage-aware-restoration-guided-uav-data-collection
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# Ubuntu: source .venv/bin/activate
python -m pip install -r requirements.txt
python -m tests.test_baer
python -m tests.test_blockage
```

## Chạy thử

```bash
python run_experiments.py --preset quick --methods BAER_DDQN
```

## Chạy đúng cấu hình huấn luyện trong notebook và bảng tham số bài báo

```bash
python run_experiments.py --preset paper --output runs/paper_seed42
```

**Lưu ý:** Chạy đầy đủ DQN, DDQN, PPO và BAER_DDQN, mỗi phương pháp **1.000.000 bước môi trường**; không phải chạy trong vài phút. Sử dụng GPU nếu có. Không dùng kết quả quick test làm kết quả bài báo.

## Đánh giá lại checkpoint, không huấn luyện

```bash
python run_experiments.py --mode evaluate --preset paper --output runs/paper_seed42
```

## Xuất history đánh giá 10–50 thiết bị và NLoS 2–6

```bash
python run_sensitivity.py --run-dir runs/paper_seed42
```

Mọi history nằm trong `runs/`: `train_steps.csv.gz` (mỗi bước), `train.csv` (mỗi episode), `eval_30.csv`, `final_test.csv`, `comparison_summary.csv`, CSV quỹ đạo và JSON bối cảnh mô phỏng. **Không có file .py vẽ hình.** `console.log` lưu lại thông báo chính của mỗi lần chạy. `runs/` mặc định không được đẩy lên GitHub.

Xem `README.md` để hiểu ý nghĩa chỉ số, bảng thư mục và các lựa chọn cấu hình.

## Đưa mã nguồn lên GitHub

Sau khi giải nén ZIP, tạo repository trống trên GitHub với tên đúng như thư mục gốc. Trong thư mục mã nguồn, chạy:

```bash
git init
git add .
git commit -m "Initial research code release"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/blockage-aware-restoration-guided-uav-data-collection.git
git push -u origin main
```

Thay `YOUR_USERNAME` bằng tài khoản GitHub của bạn. Sau đó README cho phép người khác `git clone` và chạy lại từ đầu. Không commit thư mục `runs/` theo mặc định vì chứa checkpoint và history lớn.
