"""Quick checks, no GPU or training required. Run: python test_blockage.py"""
from pathlib import Path
import numpy as np
from urban_environment import UAVHarvesting1UAV, load_config
from src.Channel import ChannelParams, Channel

p = ChannelParams()
p.map_path = str(Path('res/manhattan32.png').resolve())
p.blockage_model = 'urban3d'
p.iot_height_m = 1.5
p.building_min_height_m=8.
p.building_max_height_m=25.
p.building_height_seed=2026
p.outage_snr_db=-18.
a=Channel(p)
a.reset(32,scenario_seed=42)
b=Channel(p)
b.reset(32,scenario_seed=42)
assert np.array_equal(a.building_heights, b.building_heights)
assert np.all(a.building_heights >= 0)
# A tall building across the 3-D link blocks the ray, a removed building does not.
p.uav_altitude=10.
p.building_min_height_m=1.
p.building_max_height_m=2.
high=Channel(p)
high.reset(32,scenario_seed=42)
# Direct 3-D ray-casting correctness at an explicit one-building barrier.
high.building_heights[:] = 0.0
high.building_heights[10,10] = 20.
high._los_cache.clear()
assert not high.link_is_los((15,10),(5,10)) # ray passes tall building
high.building_heights[10,10] = 0.
high._los_cache.clear()
assert high.link_is_los((15,10),(5,10))

# In identical scenarios, the enhanced shadowing field is deterministic,
# including after revisiting the same link.
rate1 = a.compute_rate([5,5], [20,20])
rate2 = a.compute_rate([5,5], [20,20])
rate3 = b.compute_rate([5,5], [20,20])
assert rate1 == rate2 == rate3

for profile in ['manhattan32', 'manhattan32_blockage']:
    env = UAVHarvesting1UAV(load_config(profile))
    state = env.reset(seed=42)
    for t in range(15):
        state, reward, done = env.step(5) # HOVER=5, LAND=4
        if done: break
    m = env.metrics()
    assert 0 <= m['collection_ratio'] <= 1
    assert m['los_tx'] >= 0 and m['nlos_tx'] >= 0
    assert abs(m['los_collected'] + m['nlos_collected'] - m['collected_data']) < 1.e-5
    print(profile, 'CR=',round(m['collection_ratio'],3),'NLoS tx=',m['nlos_tx'],
          'outage=',m['outage_tx'])
print('PASS: geometry, deterministic shadow field, environment, metrics.')
