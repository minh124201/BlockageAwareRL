"""Blockage-specific potential: low-cost restoration of links actually blocked by roofs.

Never reads future random fading. Uses building geometry, current remaining IoT
payload and mean-SNR model. Candidate restoration positions are sparsely sampled;
A* verifies actual path energy for the best approximate candidates. Therefore
this is an approximate planner/potential, not a global-optimal 3D solver.
"""
from __future__ import annotations
import heapq
from collections import OrderedDict
from math import erf,sqrt,log10,log2
import numpy as np

class BlockageRestoration:
    def __init__(self, env, max_cost=12.0, search_candidates=5):
        self.env=env
        self.graph=env.physics.flight_graph
        self.channel=env.physics.channel
        self.max_cost=float(max_cost)
        self.search_candidates=int(search_candidates)
        self._anchor_cache={}
        self._path_cache=OrderedDict()

    def reset(self, env):
        self.env=env
        # Geometry and fixed heights do not change with scenario seed.
        if self.graph is not env.physics.flight_graph:
            self.graph=env.physics.flight_graph
            self.channel=env.physics.channel
            self._anchor_cache.clear()
            self._path_cache.clear()

    def mean_snr(self,node,device,los=True):
        x,y,k=node
        z=self.graph.height_levels[k]
        p=self.channel.params
        dist=np.sqrt(((x-float(device[0]))*p.cell_size)**2 +
                     ((y-float(device[1]))*p.cell_size)**2 +
                     (z-p.iot_height_m)**2)
        exponent=p.los_path_loss_exp if los else p.nlos_path_loss_exp
        excess=0.0 if los else float(p.nlos_excess_loss_db)
        snr=self.channel.los_norm_factor*dist**(-exponent)*10**(-excess/10)
        return float(10*np.log10(max(snr,1e-200))),float(snr)

    def blockage_outage(self,node,device):
        x,y,k=node
        pos=[x,y,self.graph.height_levels[k]]
        if self.channel.link_is_los(pos,device): return False
        los_snr,_=self.mean_snr(node,device,True)
        nlos_snr,_=self.mean_snr(node,device,False)
        threshold=float(self.channel.params.outage_snr_db)
        return bool(nlos_snr<threshold<=los_snr)

    def anchors(self, device):
        key=tuple(map(int,device))
        if key in self._anchor_cache: return self._anchor_cache[key]
        dx,dy=key
        anchors=[]
        # Sparse 3D restoration sites: sensor-centered rings (including grid
        # diagonals) instead of 5*32*32 exhaustive ray-casts per device.
        offsets={(0,0)}
        for r in (1,3,5,8,11):
            for cx,cy in ((r,0),(-r,0),(0,r),(0,-r),(r,r),(-r,r),(r,-r),(-r,-r)):
                offsets.add((cx,cy))
        for ox,oy in offsets:
            for k,z in enumerate(self.graph.height_levels):
                x,y=dx+ox,dy+oy
                node=(x,y,k)
                if not self.graph.valid(*node) or not np.isfinite(self.graph.landing_energy(node)):continue
                if not self.channel.link_is_los((x,y,z),device):continue
                mu,snr=self.mean_snr(node,device,True)
                threshold=float(self.channel.params.outage_snr_db)
                sigma=max(0.01,float(self.channel.los_shadowing_sigma))
                p=0.5*(1+erf((mu-threshold)/(sigma*sqrt(2))))
                if p<0.70:continue
                rate=log2(1+snr)
                if rate <= 0: continue
                anchors.append((node,p,rate))
        self._anchor_cache[key]=anchors
        return anchors

    def _cache_path(self,k,v):
        self._path_cache[k]=v
        self._path_cache.move_to_end(k)
        if len(self._path_cache)>18000:self._path_cache.popitem(last=False)

    def path_cost(self, src, dst):
        if src==dst:return 0.0
        key=(src,dst)
        if key in self._path_cache:return self._path_cache[key]
        graph=self.graph
        pq=[(graph.minimum_flight_energy_bound(src,dst),0.0,src)]
        best={src:0.0}
        while pq:
            _,d,node=heapq.heappop(pq)
            if d>best.get(node,np.inf)+1e-6:continue
            if node==dst:
                self._cache_path(key,d)
                return d
            for nei,e in graph.adjacent(node):
                nd=d+e
                if nd+1e-6<best.get(nei,np.inf):
                    best[nei]=nd
                    h=graph.minimum_flight_energy_bound(nei,dst)
                    heapq.heappush(pq,(nd+h,nd,nei))
        self._cache_path(key,float('inf'))
        return float('inf')

    def potential(self,env=None):
        env = env or self.env
        state=env.state
        if state.terminal or state.landed: return 0.0
        graph=self.graph
        node=(int(state.position[0]),int(state.position[1]),int(state.altitude_index))
        energy=float(state.energy_j)
        reserve=float(state.initial_energy_j)*graph.reserve
        ref=graph.reference_cost
        candidate_scores=[]
        relevant=False
        for dev in state.device_list.devices:
            rem=float(dev.data-dev.collected_data)
            if rem<=1e-8: continue
            if not self.blockage_outage(node,dev.position): continue
            relevant=True
            for anchor,prob,rate in self.anchors(dev.position):
                # Same four slots as environment, but assumes one chosen link.
                gain=prob*min(rem,float(env.physics.params.comm_steps)*rate)
                if gain<0.05:continue
                lower=graph.minimum_flight_energy_bound(node,anchor)
                return_cost=graph.landing_energy(anchor)
                collect_cost=graph.costs[5]
                if lower+return_cost+collect_cost+reserve>energy: continue
                min_steps=(abs(node[0]-anchor[0])+abs(node[1]-anchor[1])+
                           abs(node[2]-anchor[2]))
                return_steps=int(graph.return_steps[anchor[2],anchor[1],anchor[0]])
                if min_steps+1+return_steps>state.movement_budget: continue
                # Shortlist via optimistic geometric energy bound; then check
                # true collision-free path with A*.
                predicted=lower/(ref*max(gain,0.05))
                candidate_scores.append((predicted,node,anchor,gain,return_cost,collect_cost))
        if not relevant: return 0.0
        if not candidate_scores:return -self.max_cost
        candidate_scores.sort(key=lambda x:x[0])
        best=self.max_cost
        for _,src,anchor,gain,ret,collect in candidate_scores[:self.search_candidates]:
            reach=self.path_cost(src,anchor)
            if reach+ret+collect+reserve>energy:continue
            # Eq. (27): (energy_to_restore / initial_energy) divided by
            # (expected_recaptured_data / initial_total_data). Use gain floor
            # only for numeric stability with tiny normalized link rates.
            norm_energy=reach/max(1.e-9,float(state.initial_energy_j))
            norm_gain=max(gain,0.05)/max(1.e-9,float(state.initial_total_data))
            score=norm_energy/norm_gain
            best=min(best,score)
        return -float(min(self.max_cost,best))

    def safe_mask(self):
        s=self.env.state
        g=self.graph
        node=(int(s.position[0]),int(s.position[1]),int(s.altitude_index))
        return g.mask(node,float(s.energy_j),s.initial_energy_j*g.reserve,s.movement_budget)
