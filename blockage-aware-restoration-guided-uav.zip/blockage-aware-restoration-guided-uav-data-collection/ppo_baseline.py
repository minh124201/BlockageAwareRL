"""Categorical PPO-3D baseline: same observation and Global-Local CNN as DQN/DDQN.
One UAV, 8 discrete actions, unmodified Manhattan32 simulator and reward.
"""
import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical
from experiment import GlobalLocalQNet, seed_all, encode, eval_agent, summarize, UAVHarvesting1UAV, load_config
from pathlib import Path
from history_logging import StepCSVWriter, get_step_record
from tqdm.auto import tqdm
import pandas as pd
import time, json


class PPOActorCritic(nn.Module):
    def __init__(self, obs):
        super().__init__()
        self.encoder = GlobalLocalQNet(obs)
        self.encoder.output[-1] = nn.Identity()  # original CNN + 3x256 shared dense features
        self.actor = nn.Linear(256, 8)
        self.critic = nn.Linear(256, 1)
        nn.init.orthogonal_(self.actor.weight, gain=0.01)
        nn.init.zeros_(self.actor.bias)
        nn.init.orthogonal_(self.critic.weight, gain=1.0)
        nn.init.zeros_(self.critic.bias)

    def forward(self, g, l, scal):
        h = self.encoder(g, l, scal)
        return self.actor(h), self.critic(h).squeeze(-1)


class PPOAgent:
    mask = False
    shape = False
    feedback = False
    def __init__(self, obs, device, seed, lr=3e-5, gamma=0.95,
                 gae_lambda=0.95, clip_eps=0.20, ent_coef=0.01,
                 value_coef=0.5, epochs=4, minibatch=64):
        seed_all(seed)
        self.device=device; self.net=PPOActorCritic(obs).to(device)
        self.optimizer=torch.optim.Adam(self.net.parameters(),lr=lr,eps=1e-5)
        self.gamma=gamma;self.gae_lambda=gae_lambda
        self.clip_eps=clip_eps;self.ent_coef=ent_coef
        self.value_coef=value_coef;self.epochs=epochs;self.minibatch=minibatch
        self.rng=np.random.default_rng(seed+701)
        self.updates=0;self.last_loss=float('nan')

    def obs_tensor(self, obs):
        return [torch.as_tensor(v[None],dtype=torch.float32,device=self.device) for v in obs]

    @torch.no_grad()
    def act_and_value(self,obs):
        logits, value=self.net(*self.obs_tensor(obs))
        dist=Categorical(logits=logits)
        a=dist.sample()
        return int(a.item()),float(dist.log_prob(a).item()),float(value.item())

    @torch.no_grad()
    def value(self,obs):
        return float(self.net(*self.obs_tensor(obs))[1].item())

    @torch.no_grad()
    def action(self,obs,rng=None,mask=None,greedy=False,target=False):
        logits,_=self.net(*self.obs_tensor(obs))
        if greedy:return int(logits.argmax(dim=-1).item())
        return int(Categorical(logits=logits).sample().item())

    def update(self, rollouts):
        if not rollouts:return float('nan')
        rewards=np.array([x['reward'] for x in rollouts],np.float32)
        dones=np.array([x['done'] for x in rollouts],np.float32)
        values=np.array([x['value'] for x in rollouts],np.float32)
        next_values=np.array([x['next_value'] for x in rollouts],np.float32)
        gaes=np.empty(len(rollouts),np.float32)
        last_gae=0.0
        for t in reversed(range(len(rollouts))):
            nonterminal=1.0-dones[t]
            delta=rewards[t]+self.gamma*nonterminal*next_values[t]-values[t]
            last_gae=delta+self.gamma*self.gae_lambda*nonterminal*last_gae
            gaes[t]=last_gae
        returns=gaes+values
        advantages=(gaes-gaes.mean())/(gaes.std()+1e-8)
        acts=torch.tensor([x['action'] for x in rollouts],device=self.device,dtype=torch.int64)
        old_logp=torch.tensor([x['logp'] for x in rollouts],device=self.device,dtype=torch.float32)
        adv=torch.tensor(advantages,device=self.device)
        ret=torch.tensor(returns,device=self.device)
        stack=[torch.as_tensor(np.stack([x['obs'][j] for x in rollouts]),device=self.device,dtype=torch.float32)
               for j in range(3)]
        n=len(rollouts)
        last_loss=float('nan')
        for _ in range(self.epochs):
            order=self.rng.permutation(n)
            for start in range(0,n,self.minibatch):
                idx=order[start:start+self.minibatch]
                logits,v=self.net(*[z[idx] for z in stack]); d=Categorical(logits=logits)
                ratio=(d.log_prob(acts[idx])-old_logp[idx]).exp()
                policy_loss=-torch.minimum(ratio*adv[idx],ratio.clamp(1-self.clip_eps,1+self.clip_eps)*adv[idx]).mean()
                value_loss=0.5*(v-ret[idx]).square().mean()
                loss=policy_loss+self.value_coef*value_loss-self.ent_coef*d.entropy().mean()
                self.optimizer.zero_grad(set_to_none=True);loss.backward()
                nn.utils.clip_grad_norm_(self.net.parameters(),0.5)
                self.optimizer.step();self.updates+=1;last_loss=float(loss.item())
        self.last_loss=last_loss
        return last_loss


def train_ppo(cfg,args,device):
    from experiment import eval_agent, summarize, save_checkpoint
    seed_all(args.seed)
    env=UAVHarvesting1UAV(cfg)
    env.reset(args.seed+100000)
    obs=encode(env,False)
    agent=PPOAgent(obs,device,args.seed+303,epochs=args.ppo_epochs,
                   minibatch=args.ppo_minibatch)
    out=Path(args.output)/'PPO_3D';out.mkdir(parents=True,exist_ok=True)
    history_writer=(StepCSVWriter(out/'train_steps.csv.gz') if args.log_train_steps else None)
    train_rows=[];eval_rows=[];eval_scenarios=[];rollout=[]
    step=0;episodes=0;best_cral=-float('inf');latest_loss=float('nan')
    next_eval=args.eval_every; tstart=time.time()
    env.reset(args.seed+1_000_000+episodes)
    bar=tqdm(total=args.steps,desc='PPO_3D train',unit='step')
    while step<args.steps:
        ob=encode(env,False)
        action,logp,v=agent.act_and_value(ob)
        prev_collected=float(env.state.get_collected_data())
        _,rew,done=env.step(action)
        next_ob=encode(env,False)
        next_v=0.0 if done else agent.value(next_ob)
        rollout.append({'obs':ob,'action':action,'logp':logp,'value':v,
                        'reward':float(rew),'done':bool(done),'next_value':next_v})
        step+=1;bar.update(1)
        if history_writer is not None:
            history_writer.write(get_step_record(
                env,'PPO_3D','train',step,episodes+1,
                args.seed+1_000_000+episodes,action,rew,
                prev_collected,latest_loss,done))
            if step%10000==0:history_writer.flush()
        if done:
            episodes+=1
            m=env.metrics();m.update(step=step,episode=episodes,method='PPO_3D',
                      loss=latest_loss,updates=agent.updates,episode_complete=True)
            train_rows.append(m)
            if step<args.steps: env.reset(args.seed+1_000_000+episodes)
        if len(rollout)>=args.ppo_rollout or step==args.steps:
            latest_loss=agent.update(rollout)
            rollout.clear()
        if step>=next_eval or step==args.steps:
            seeds=range(3_000_000,3_000_000+args.eval_episodes)
            table=eval_agent(agent,cfg,seeds)
            row=summarize(table,'PPO_3D',step);eval_rows.append(row)
            table=table.copy();table.insert(0,'step',step);table.insert(0,'method','PPO_3D')
            eval_scenarios.append(table)
            save_checkpoint(agent,out/'last.pt',step,args.seed,'PPO_3D')
            if row['cral']>best_cral:
                best_cral=row['cral'];save_checkpoint(agent,out/'best.pt',step,args.seed,'PPO_3D')
            pd.DataFrame(train_rows).to_csv(out/'train.csv',index=False)
            pd.DataFrame(eval_rows).to_csv(out/'eval_30.csv',index=False)
            pd.concat(eval_scenarios,ignore_index=True).to_csv(out/'eval_scenarios.csv',index=False)
            bar.set_postfix(CRAL=f'{row["cral"]:.3f}',iot=f'{row["iot_success_ratio"]:.3f}')
            while next_eval<=step: next_eval+=args.eval_every
    bar.close()
    if history_writer is not None:history_writer.close()
    ck=torch.load(out/'best.pt',map_location=device,weights_only=False)
    agent.net.load_state_dict(ck['network'])
    test=eval_agent(agent,cfg,range(4_000_000,4_000_000+args.test_episodes),
                    trajectory_dir=out/'trajectories',scenario_dir=Path(args.output)/'scenarios',
                    trace_count=args.trace_count)
    test.to_csv(out/'final_test.csv',index=False)
    row=summarize(test,'PPO_3D',ck['step'])
    row.update(train_steps=step,gradient_updates=agent.updates,
               wall_seconds=time.time()-tstart,train_steps_prefill=0)
    (out/'config_used.json').write_text(json.dumps({**vars(args),'method':'PPO_3D',
            'ppo':'clipped categorical PPO + GAE','simulation_config':cfg},indent=2,default=list))
    print('TEST',row,flush=True)
    return row
