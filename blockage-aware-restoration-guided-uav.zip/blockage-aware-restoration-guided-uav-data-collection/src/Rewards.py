from src.State import State
from src.base.GridActions import GridActions
from src.base.GridRewards import GridRewards, GridRewardParams


class RewardParams(GridRewardParams):
    def __init__(self):
        super().__init__()
        self.data_multiplier = 1.0


# Class used to track rewards
class Rewards(GridRewards):
    cumulative_reward: float = 0.0

    def __init__(self, reward_params: RewardParams, stats):
        super().__init__(stats)
        self.params = reward_params
        self.reset()

    def calculate_reward(self, state: State, action: GridActions, next_state: State):
        if hasattr(next_state, 'initial_energy_j'):
            e_ref = float(getattr(next_state, 'energy_reference_j', 32.0))
            cost = float(next_state.last_action_energy_j)
            reward = 0.0 if next_state.landed else -float(self.params.movement_penalty)*(cost/e_ref)
            if next_state.last_invalid_action: reward -= float(self.params.boundary_penalty)
            if next_state.energy_exhausted: reward -= float(self.params.empty_battery_penalty)
        else:
            reward = self.calculate_motion_rewards(state, action, next_state)

        # Reward the collected data
        reward += self.params.data_multiplier * (state.get_remaining_data() - next_state.get_remaining_data())

        # Cumulative reward
        self.cumulative_reward += reward

        return reward
