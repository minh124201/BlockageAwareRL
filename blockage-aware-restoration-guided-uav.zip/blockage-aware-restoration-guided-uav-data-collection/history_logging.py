"""History and 3D trace utilities for the original Manhattan32 simulator.
No changes to the physics, channel, reward or scenario generation.
"""
from __future__ import annotations
import csv, gzip, json
from pathlib import Path
import numpy as np
import pandas as pd

class StepCSVWriter:
    """O(1) RAM, one record per env.step. Compressed, streaming.
    Fast enough for long training jobs; avoid loading all 1M rows in RAM.
    """
    FIELDS = ['method','phase','global_step','episode','episode_step','scenario_seed',
              'action','x_cell','y_cell','altitude_m','reward_step','episode_reward',
              'collection_ratio','cral','landed','energy_used_j','energy_remaining_j',
              'iot_total','iot_fully_collected','iot_success_ratio','collected_data',
              'data_delta','no_service_slots','blockage_no_service_steps',
              'blockage_outage','restored_events','blockage_restored_events','done','loss']
    def __init__(self,path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        self.fd=gzip.open(self.path,'wt',newline='',encoding='utf8',compresslevel=3)
        self.writer=csv.DictWriter(self.fd,fieldnames=self.FIELDS)
        self.writer.writeheader()
    def write(self,record):
        self.writer.writerow({k:record.get(k) for k in self.FIELDS})
    def flush(self):self.fd.flush()
    def close(self):self.fd.close()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

def get_step_record(env,method,phase,global_step,episode,scenario_seed,
                    action,reward,prev_data,loss,done):
    s=env.state; lm=env.physics.link_metrics
    total=float(s.get_total_data());col=float(s.get_collected_data())
    devices=s.device_list.devices
    full=sum(float(d.collected_data)>=float(d.data)-1e-8 for d in devices)
    x,y=map(int,s.position)
    return dict(method=method,phase=phase,global_step=int(global_step),
        episode=int(episode),episode_step=int(env.steps),scenario_seed=int(scenario_seed),
        action=int(action),x_cell=x,y_cell=y,
        altitude_m=float(s.altitude_m),reward_step=float(reward),
        episode_reward=float(env.rewards.cumulative_reward),
        collection_ratio=col/max(1e-9,total),
        cral=col/max(1e-9,total)*int(s.all_landed),
        landed=int(s.all_landed),energy_used_j=float(env.physics.episode_energy_j),
        energy_remaining_j=float(s.energy_j),iot_total=len(devices),
        iot_fully_collected=int(full),iot_success_ratio=float(full/max(1,len(devices))),
        collected_data=col,data_delta=float(col-prev_data),
        no_service_slots=int(lm['no_service_slots']),
        blockage_no_service_steps=int(lm['blockage_no_service_steps']),
        blockage_outage=int(bool(getattr(s,'last_blockage_outage',False))),
        restored_events=int(lm['restored_events']),
        blockage_restored_events=int(lm['blockage_restored_events']),
        done=int(done),loss=float(loss))

def scenario_metadata(env,seed):
    s=env.state
    heights=np.asarray(env.physics.channel.building_heights)
    nfz=np.asarray(s.no_fly_zone)
    landing=np.asarray(s.landing_zone)
    buildings=[dict(x=int(x),y=int(y),height_m=float(heights[y,x]))
       for y,x in zip(*np.where(heights>0))]
    return dict(seed=int(seed),map_size_cells=[int(nfz.shape[1]),int(nfz.shape[0])],
         cell_size_m=float(env.physics.channel.params.cell_size),
         uav_initial=dict(x=int(s.position[0]),y=int(s.position[1]),
             altitude_m=float(s.altitude_m),energy_j=float(s.energy_j)),
         devices=[dict(id=int(j),x=int(d.position[0]),y=int(d.position[1]),
                       z_m=float(env.physics.channel.params.iot_height_m),
                       total_data=float(d.data)) for j,d in enumerate(s.device_list.devices)],
         buildings=buildings,
         no_fly_cells=[[int(x),int(y)] for y,x in zip(*np.where(nfz))],
         landing_cells=[[int(x),int(y)] for y,x in zip(*np.where(landing))])

def write_json(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')

def write_traces(base,method,seed,metadata,rows,devices):
    base=Path(base);(base/'trajectories').mkdir(parents=True,exist_ok=True)
    (base/'scenarios').mkdir(parents=True,exist_ok=True)
    clean=method.replace('/','_')
    pd.DataFrame(rows).to_csv(base/'trajectories'/f'trajectory_{clean}_seed{seed}.csv',index=False)
    pd.DataFrame(devices).to_csv(base/'trajectories'/f'devices_{clean}_seed{seed}.csv',index=False)
    scenario_file=base/'scenarios'/f'scenario_seed{seed}.json'
    if not scenario_file.exists():write_json(scenario_file,metadata)
