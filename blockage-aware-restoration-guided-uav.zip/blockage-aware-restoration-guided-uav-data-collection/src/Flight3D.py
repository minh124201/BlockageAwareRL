"""Discrete three-dimensional flight and *surrogate* step-energy model.

All flight energies are in synthetic J-equivalent values obtained by power *
step_duration_s. Power settings are illustrative, NOT measured UAV parameters.
Fixed mission step budget also remains active, to bound episode length and allow
comparable scenarios. 3D collision checking forbids occupying any building cell
below roof + clearance and any original no-fly cell at any altitude.
"""
from __future__ import annotations
import heapq
from collections import deque
import numpy as np

# Keep actions 0..5 identical to the upstream project; UP=6, DOWN=7.
DELTAS = {0:(0,1,0),1:(1,0,0),2:(0,-1,0),3:(-1,0,0),6:(0,0,1),7:(0,0,-1)}


class FlightGraph:
    def __init__(self, no_fly, building_heights, landing, flight_params):
        self.nfz = np.asarray(no_fly, dtype=bool)
        self.heights = np.asarray(building_heights, dtype=float)
        self.landing = np.asarray(landing, dtype=bool)
        self.height_levels = tuple(float(v) for v in flight_params['altitude_levels_m'])
        self.clearance = float(flight_params['roof_clearance_m'])
        self.min_height = self.height_levels[0]
        self.height_step = self.height_levels[1]-self.height_levels[0]
        self.width = int(self.nfz.shape[1]); self.height = int(self.nfz.shape[0])
        self.dt = float(flight_params['step_duration_s'])
        powers = flight_params['power_w']
        self.costs = {int(i):float(powers[n])*self.dt + float(powers['radio'])*self.dt
                      for i,n in [(0,'horizontal'),(1,'horizontal'),(2,'horizontal'),(3,'horizontal'),
                                  (6,'up'),(7,'down')]}
        self.costs[5] = (float(powers['hover'])+float(powers['radio']))*self.dt
        self.costs[4] = float(powers['land'])*self.dt
        self.reference_cost = self.costs[0]
        self.reserve = float(flight_params['reserve_fraction'])
        self.num_levels = len(self.height_levels)
        # Static graph: compute exact minimum energy to any ground-level landing location.
        self.return_cost = self._return_costs()
        self.return_steps = self._return_steps()

    def key(self,x,y,k):
        return (int(x),int(y),int(k))

    def valid(self,x,y,k):
        x,y,k = self.key(x,y,k)
        return (0<=x<self.width and 0<=y<self.height and 0<=k<self.num_levels
                and not self.nfz[y,x]
                and self.height_levels[k] > self.heights[y,x]+self.clearance)

    def adjacent(self,node, reverse=False):
        x,y,k=node
        for action,(dx,dy,dk) in DELTAS.items():
            xx,yy,kk=x+dx,y+dy,k+dk
            if self.valid(xx,yy,kk):
                yield (xx,yy,kk),self.costs[action if not reverse else ({6:7,7:6}.get(action,action))]

    def _return_costs(self):
        dist = np.full((self.num_levels,self.height,self.width),np.inf,dtype=np.float32)
        pq=[]
        for y,x in np.argwhere(self.landing):
            x,y=int(x),int(y)
            if self.valid(x,y,0):
                dist[0,y,x]=self.costs[4]
                heapq.heappush(pq,(self.costs[4],(x,y,0)))
        while pq:
            d,(x,y,k)=heapq.heappop(pq)
            if d>float(dist[k,y,x])+1e-3: continue
            for (xx,yy,kk),edge in self.adjacent((x,y,k),reverse=True):
                nd=d+edge
                if nd+1e-4<float(dist[kk,yy,xx]):
                    dist[kk,yy,xx]=nd
                    heapq.heappush(pq,(nd,(xx,yy,kk)))
        return dist

    def _return_steps(self):
        steps=np.full((self.num_levels,self.height,self.width),9999,dtype=np.int16)
        todo=deque()
        for y,x in np.argwhere(self.landing):
            x,y=int(x),int(y)
            if self.valid(x,y,0):
                steps[0,y,x]=1  # includes LAND
                todo.append((x,y,0))
        while todo:
            x,y,k=todo.popleft()
            for (xx,yy,kk),_ in self.adjacent((x,y,k),reverse=True):
                if steps[kk,yy,xx]>steps[k,y,x]+1:
                    steps[kk,yy,xx]=steps[k,y,x]+1
                    todo.append((xx,yy,kk))
        return steps

    def landing_energy(self,node):
        x,y,k=node
        if not self.valid(x,y,k): return np.inf
        return float(self.return_cost[k,y,x])

    def after(self,node,action):
        if action in DELTAS:
            dx,dy,dk=DELTAS[action]
            return (node[0]+dx,node[1]+dy,node[2]+dk)
        return node

    def action_valid(self,node,action):
        dest=self.after(node,action)
        if action==4: return node[2]==0 and bool(self.landing[node[1],node[0]])
        return self.valid(*dest)

    def mask(self,node,energy,reserve_energy,remaining_steps=None):
        vals=[]
        for action in range(8):
            if not self.action_valid(node,action):
                vals.append(False);continue
            cost=self.costs[action]
            if action==4:
                vals.append(energy>=cost);continue
            dest=self.after(node,action)
            safe_energy=energy-cost>=self.landing_energy(dest)+reserve_energy-1e-5
            safe_steps=(remaining_steps is None or
                        remaining_steps-1>=int(self.return_steps[dest[2],dest[1],dest[0]]))
            vals.append(safe_energy and safe_steps)
        # If no safe path survives an unexpectedly low-energy state, allow
        # valid actions as a recovery fallback; never produce all -inf Q targets.
        if not any(vals):
            vals=[self.action_valid(node,a) for a in range(8)]
        return np.asarray(vals,dtype=np.bool_)

    def minimum_flight_energy_bound(self,src,dst):
        """Admissible lower bound (not a proof of reachability) for restoration scores."""
        ax,ay,ak=src; bx,by,bk=dst
        return (abs(ax-bx)+abs(ay-by))*self.costs[0] + max(0,bk-ak)*self.costs[6] + max(0,ak-bk)*self.costs[7]
