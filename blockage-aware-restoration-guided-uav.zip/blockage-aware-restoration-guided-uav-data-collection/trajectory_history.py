"""Read-only export of per-step trajectories and scenario metadata."""
import json
from pathlib import Path
import numpy as np
import pandas as pd


def snapshot(env):
    s=env.state;p=env.physics
    return {'x_grid':int(s.position[0]),'y_grid':int(s.position[1]),
            'z_m':float(s.altitude_m),'energy_j':float(s.energy_j),
            'collected_data':float(s.get_collected_data()),
            'cum_reward':float(env.rewards.cumulative_reward),
            'landed':bool(s.landed),'done':bool(s.all_terminal),
            'link':dict(p.link_metrics),
            'collected_by_iot':[float(d.collected_data) for d in s.device_list.devices]}


def save_scenario(env,seed,outdir):
    """Export *actual* building positions/heights, NFZ, IoTs, landing and start."""
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    dest=outdir/f'scenario_{int(seed)}.json'
    if dest.exists():return dest
    s=env.state;ch=env.physics.channel;h=np.asarray(ch.building_heights)
    heights=[{'x':int(x),'y':int(y),'height_m':round(float(h[y,x]),4)}
             for y,x in np.argwhere(h>0.1)]
    data={'seed':int(seed),'grid_size':[int(s.shape[1]),int(s.shape[0])],
          'cell_size_m':float(ch.params.cell_size),
          'start_grid':[int(s.position[0]),int(s.position[1])],
          'start_altitude_m':float(s.altitude_m),
          'iot_altitude_m':float(ch.params.iot_height_m),
          'buildings':heights,
          'no_fly_cells':[[int(x),int(y)] for y,x in np.argwhere(s.no_fly_zone)],
          'landing_cells':[[int(x),int(y)] for y,x in np.argwhere(s.landing_zone)],
          'devices':[{'id':i,'x_grid':int(d.position[0]),'y_grid':int(d.position[1]),
                      'z_m':float(ch.params.iot_height_m),'initial_data':float(d.data)}
                     for i,d in enumerate(s.device_list.devices)]}
    dest.write_text(json.dumps(data,indent=2),encoding='utf8')
    return dest


def step_record(before, after, env, seed, method, t, action, reward):
    record={'method':method,'scenario_seed':int(seed),'step':int(t),'action':int(action),
         'reward_step':float(reward),'cumulative_reward':after['cum_reward'],
         'x_grid':after['x_grid'],'y_grid':after['y_grid'],'z_m':after['z_m'],
         'x_m':after['x_grid']*env.physics.channel.params.cell_size,
         'y_m':after['y_grid']*env.physics.channel.params.cell_size,
         'x_prev':before['x_grid'],'y_prev':before['y_grid'],'z_prev_m':before['z_m'],
         'energy_used_step_j':before['energy_j']-after['energy_j'],
         'energy_remaining_j':after['energy_j'],
         'data_collected_step':after['collected_data']-before['collected_data'],
         'data_collected_total':after['collected_data'],
         'collection_ratio':float(env.state.get_collection_ratio()),
         'landed':int(after['landed']),'done':int(after['done']),
         'last_blockage_outage':int(getattr(env.state,'last_blockage_outage',False)),
         'device_com_idx':int(env.state.device_coms[0])}
    for key in ['los_tx','nlos_tx','outage_tx','no_service_slots','restored_events',
                'blockage_no_service_steps','blockage_restored_events','recovery_delay_sum']:
        record['delta_'+key]=after['link'].get(key,0)-before['link'].get(key,0)
        record['cum_'+key]=after['link'].get(key,0)
    return record


def save_trajectory(seed,method,env,steps,scenario_dir,trajectory_dir):
    tdir=Path(trajectory_dir);tdir.mkdir(parents=True,exist_ok=True)
    suffix=f'{method}_seed{seed}'
    pd.DataFrame(steps).to_csv(tdir/f'trajectory_{suffix}.csv',index=False)
    device_rows=[{'method':method,'scenario_seed':int(seed),'device_id':i,
                  'x_grid':int(d.position[0]),'y_grid':int(d.position[1]),
                  'initial_data':float(d.data),'collected_data':float(d.collected_data),
                  'fully_collected':int(d.depleted),
                  'partial_collected':int(0<float(d.collected_data)<float(d.data)-1e-8)}
                 for i,d in enumerate(env.state.device_list.devices)]
    pd.DataFrame(device_rows).to_csv(tdir/f'devices_{suffix}.csv',index=False)


